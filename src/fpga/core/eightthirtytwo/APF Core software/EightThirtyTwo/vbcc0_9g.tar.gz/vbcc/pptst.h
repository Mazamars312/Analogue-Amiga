test
hello
con\
catenated
not\ 
concatenated
??= 
??( 
??/ 
??) 
??' 
??< 
??! 
??> 
??- 
From standard: printf("Eh???/n");
con??/
catenated with trigraph

# /*   */ define fail succeed
fail
#undef fail
 #define fail succeed
fail

#define x(a,b) a+b

x(12
23
,
34
45
)

