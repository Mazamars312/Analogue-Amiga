Open source **I/O Controller for FPGAs** allowing communication via **SPI**, **I²C**, **UART**, **JTAG**, **Avalon** or **AMBA** (Advanced Microcontroller Bus Architecture) on **RISC** based CPUs running **Linux**.

## How it works?



## Points of interest

### Design goals and decisions

**MiMiC** was designed to be:

1. **Agnostic:** For better or worse, there are many FPGA devices out there, and this software should work with as many of them as possible.
2. **Portable:** This controller should be portable both across different platforms and compilers. The default settings should work for most 32 bit and 64 bit RISC derivatives CPUs running Linux.
3. **Lightweight:** One size doesn't fit all, follow the "enable only what you need" guideline.
4. **Unintrusive:** Avoid forcing any particular hardware or a vendor on the user.
5. **Modular:** Maintainability depends on modularity and that is at the core of everything. Good modularization makes building and packaging for different devices easy.
6. **Standardized:** A common architecture leads to a significant base of code that is commonly shared between applications. This implements DRY and keeps developers from having to re-invent the wheel.
7. **Heavily Documented:** Documentation is scaling for knowledge, the “shoulder-tap” model of “I’ll just ask someone online” DOES NOT SCALE. Good documentation is _hard_ and requires _empathy_. Forget how easy it feels now that you know and understand what it felt like not to know.

## Contributing

This project welcomes contributions and suggestions.

At this time if you have suggestions or questions you can leave the comments on the forum or create issues on this repository.
If you'd like to contribute, please review the Contributing Guidelines.

If you’ve found a bug or have a suggestion, please don’t hesitate to detail these in the issue tracker.

## Compatible Hardware

> The development is co-ordinated via the project page.

## Lifecycle and release cadence

Rætro publishes new releases of MiMiC on a regular basis, enabling the community and developers to access newer capabilities.

### Versioning

**MiMiC** adopts a version format of **X.Y.Z** based on the Semantic Versioning Specification ([SemVer](https://semver.org/)).
Under this scheme, version numbers and the way they change convey meaning about the underlying code and what has been modified from one version to the next.

So given a version number MAJOR.MINOR.PATCH:

1. **MAJOR** version changes when incompatible changes made,
2. **MINOR** version changes when functionality are added in a backwards compatible manner, and
3. **PATCH** version changes when making backwards compatible bug fixes.

Additional labels for pre-release and build metadata are available as extensions to the MAJOR.MINOR.PATCH format.

Build metadata **MAY** be denoted by appending separated identifiers immediately following the patch or pre-release version.
Identifiers **MUST** comprise of only **ASCII alphanumeric and hyphens**. Identifiers **MUST NOT** be empty.
Build metadata **MUST** be ignored when determining version precedence.

**Example:**

Alpha < Final Release

```text
1.0.1-alpha < 1.0.1-alpha.1 < 1.0.1-alpha.2 < 1.0.1-alpha.beta
1.0.1-beta  < 1.0.1-beta.2  < 1.0.1-beta.11
1.0.1-rc.1  < 1.0.1-rc.2
1.0.1
```

## Building

```bash
git clone https://github.com/raetro/pi-spi-fpga
cd pi-spi-fpga
mkdir build
cd build
cmake ..
make
sudo ./PiSPI
```



## Documentation

The documentation files can be found in `docs` folder.
In order to generate the documentation run `make docs`, you can read at `docs/<format>/<index.ext>`.

## Contributions

If you want to report bugs or contribute patches, please submit them to the project repository.

## Credits and acknowledgment

- Alastair M. Robinson
- Dennis van Weeren
- Jakub Bednarski
- Mike Johnson
- Richard Johnson
- Till Harbaum
- Victor Trucco 
- And to all of those who contribute or have contributed on the all related projects throughout the years! <3

## Legal Notices

This work is licensed under multiple licenses.

* All original source code is licensed under [GNU General Public License v3.0 or later] unless implicit indicated.
* All documentation is licensed under [Creative Commons Attribution-ShareAlike 4.0 International] Public License.
* Some configuration and data files are licensed under [Creative Commons Zero v1.0 Universal].

Rætro and any contributors reserve all others rights, whether under their respective copyrights, patents, or trademarks, whether by implication, estoppel or otherwise.

The authors and contributors or any of its maintainers are in no way associated with or endorsed by ARM®, Intel®, Xilinx®, Lattice®  or any other company not implicit indicated. All other brands or product names are the property of their respective holders.

## Powered by Open-Source Software

This project borrowed and use code from several other projects. A great thanks to their efforts!

For more accurate information, check the individual license files inside `pkg/licenses`.

| Software/Library                                           | License                                    | Copyright/Developer      |
| :--------------------------------------------------------- | :----------------------------------------- | :----------------------- |
| [ARM Firmware](https://code.google.com/archive/p/minimig/) | [GNU General Public License v3.0 or later] | 2008 (c) Jakub Bednarski |
| [MiST](https://github.com/mist-devel/mist-firmware)        | [GNU General Public License v3.0 or later] | 2012 (c) Till Harbaum    |

[GNU General Public License v3.0 or later]: https://spdx.org/licenses/GPL-3.0-or-later.html