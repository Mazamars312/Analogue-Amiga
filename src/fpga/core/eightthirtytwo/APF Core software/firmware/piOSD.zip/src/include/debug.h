/*******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2005-2021, The Raetro authors and contributors
 *******************************************************************************
 *
 * PiSPi
 * Copyright (c) 2005-2021, The Raetro Authors (see AUTHORS file)
 *
 * PiSPi is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the
 * Free Software Foundation, version 3 or (at your option) any later version.
 *
 * PiSPi is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with PiSPi. If not, see <https://www.gnu.org/licenses>.
 *
 ******************************************************************************/

/*!*****************************************************************************
 * @file debug.h
 * @brief Interface of a fancy colored Debugger.
 ******************************************************************************/

#ifndef MIMIC_DEBUG_H
#define MIMIC_DEBUG_H

// Set up for C function definitions, even when using C++.
#define nullptr NULL

#include <cstring>
#include <cstdio>
#include <iostream>
#include <malloc.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MIMIC_DEBUG

// Colours and text customisation
#define VT_BOLD       "\x1b[1m"
#define VT_RESET      "\x1b[0m"
#define VT_WHITE_FG   "\x1b[38;5;254m"
// Debugger Specific Colors for Lines
#define VT_FILE_BG    "\x1b[48;5;232m"
#define VT_LINE_BG    "\x1b[48;5;233m"
#define VT_TIME_BG    "\x1b[48;5;234m"
// Default Debugging Levels
#define VT_DEBUG      "\x1b[38;5;99m"
#define VT_DEBUG_BG   "\x1b[48;5;55m"
#define VT_ERROR      "\x1b[38;5;160m"
#define VT_ERROR_BG   "\x1b[48;5;160m"
#define VT_INFO       "\x1b[38;5;28m"
#define VT_INFO_BG    "\x1b[48;5;28m"
#define VT_VERBOSE    "\x1b[38;5;244m"
#define VT_VERBOSE_BG "\x1b[48;5;244m"
#define VT_WARN       "\x1b[38;5;172m"
#define VT_WARN_BG    "\x1b[48;5;172m"
// Default Application Specific Levels
#define VT_APP        "\x1b[38;5;39m"
#define VT_APP_BG     "\x1b[48;5;39m"
#define VT_CORE       "\x1b[38;5;65m"
#define VT_CORE_BG    "\x1b[48;5;65m"
#define VT_EVENTS     "\x1b[38;5;71m"
#define VT_EVENTS_BG  "\x1b[48;5;71m"
#define VT_FPGA       "\x1b[38;5;135m"
#define VT_FPGA_BG    "\x1b[48;5;135m"
#define VT_FS         "\x1b[38;5;132m"
#define VT_FS_BG      "\x1b[48;5;132m"
#define VT_I2C        "\x1b[38;5;178m"
#define VT_I2C_BG     "\x1b[48;5;178m"
#define VT_INPUT      "\x1b[38;5;142m"
#define VT_INPUT_BG   "\x1b[48;5;142m"
#define VT_NET        "\x1b[38;5;166m"
#define VT_NET_BG     "\x1b[48;5;166m"
#define VT_OSD        "\x1b[38;5;131m"
#define VT_OSD_BG     "\x1b[48;5;131m"
#define VT_PERIF      "\x1b[38;5;111m"
#define VT_PERIF_BG   "\x1b[48;5;111m"
#define VT_SPI        "\x1b[38;5;62m"
#define VT_SPI_BG     "\x1b[48;5;62m"
#define VT_SYSTEM     "\x1b[38;5;246m"
#define VT_SYSTEM_BG  "\x1b[48;5;246m"
#define VT_TIMER      "\x1b[38;5;200m"
#define VT_TIMER_BG   "\x1b[48;5;200m"
#define VT_VIDEO      "\x1b[38;5;33m"
#define VT_VIDEO_BG   "\x1b[48;5;33m"

//Trace level definitions
#define TRACE_LEVEL_OFF      0
#define TRACE_LEVEL_FATAL    1
#define TRACE_LEVEL_ERROR    2
#define TRACE_LEVEL_WARNING  3
#define TRACE_LEVEL_INFO     4
#define TRACE_LEVEL_DEBUG    5
#define TRACE_LEVEL_VERBOSE  6

//Default trace level
#ifndef TRACE_LEVEL
#define TRACE_LEVEL TRACE_LEVEL_DEBUG
#endif

//Trace output redirection
#ifndef TRACE_PRINTF
#define TRACE_PRINTF(...) fprintf(stderr, __VA_ARGS__)
#endif

//Debugging macros
#if (TRACE_LEVEL >= TRACE_LEVEL_FATAL)
#else
#endif

#if (TRACE_LEVEL >= TRACE_LEVEL_ERROR)
#else
#endif

#if (TRACE_LEVEL >= TRACE_LEVEL_WARNING)
#else
#endif

#if (TRACE_LEVEL >= TRACE_LEVEL_INFO)
#else
#endif

#if (TRACE_LEVEL >= TRACE_LEVEL_DEBUG)
#else
#endif

#if (TRACE_LEVEL >= TRACE_LEVEL_VERBOSE)
#else
#endif

#ifdef MIMIC_DEBUG
static struct {
	const char *label;
	const char *vt_fg_color;
	const char *vt_bg_color;
} LOG_LEVEL[] = {
	{"DEBUG"   , VT_DEBUG  , VT_DEBUG_BG  }, /**< 0 */
	{"ERROR"   , VT_ERROR  , VT_ERROR_BG  }, /**< 1 */
	{"INFO"    , VT_INFO   , VT_INFO_BG   }, /**< 2 */
	{"VERBOSE" , VT_VERBOSE, VT_VERBOSE_BG}, /**< 3 */
	{"WARN"    , VT_WARN   , VT_WARN_BG   }, /**< 4 */
	// MiMiC Specific Colors
	{"MIMIC"   , VT_APP    , VT_APP_BG    }, /**< 5 */
	{"CORE"    , VT_CORE   , VT_CORE_BG   }, /**< 6 */
	{"EVENTS"  , VT_EVENTS , VT_EVENTS_BG }, /**< 7 */
	{"FPGA"    , VT_FPGA   , VT_FPGA_BG   }, /**< 8 */
	{"FS"      , VT_FS     , VT_FS_BG     }, /**< 9 */
	{"I2C"     , VT_I2C    , VT_I2C_BG    }, /**< 10 */
	{"INPUT"   , VT_INPUT  , VT_INPUT_BG  }, /**< 11 */
	{"NETWORK" , VT_NET    , VT_NET_BG    }, /**< 12 */
	{"OSD"     , VT_OSD    , VT_OSD_BG    }, /**< 13 */
	{"PERIF"   , VT_PERIF  , VT_PERIF_BG  }, /**< 14 */
	{"SPI"     , VT_SPI    , VT_SPI_BG    }, /**< 15 */
	{"SYSTEM"  , VT_SYSTEM , VT_SYSTEM_BG }, /**< 16 */
	{"TIMER"   , VT_TIMER  , VT_TIMER_BG  }, /**< 17 */
	{"VIDEO"   , VT_VIDEO  , VT_VIDEO_BG  }, /**< 18 */
};

inline static const char *get_filename_without_extension(const char *filename) {
	char *retstr;
	char *lastdot;
	retstr = static_cast<char *>(malloc(strlen(filename) + 1));
	strcpy(retstr, filename);
	lastdot = strrchr(retstr, '.');
	if(lastdot != nullptr) {
		*lastdot = '\0';
	}
	return retstr;
}

inline static const char *get_filename_without_path(const char *filename) {
	const char *file = get_filename_without_extension(filename);
	const char *e;
	char *result;
	char *copy = static_cast<char *>(malloc(2000));
	// Adding special case for certain alias
	if(strstr(file, " / ") != nullptr) {
		return strdup(file);
	}
	e = strrchr(file, '/');
	if(e == nullptr) {
		result = (char *) malloc(strlen(file) + 1);
		strcpy(result, file);
	} else {
		result = (char *) malloc(strlen(e + 1) + 1);
		strcpy(result, e + 1);
	}
	strcpy(copy, result);
	for (int i = 0; copy[i]; i++) {
		copy[i] = (char) toupper(copy[i]);
	}
	free((void *) file);
	return copy;
}

inline static char *get_time () {
	char current_time[100];
	time_t now = time (nullptr);
	strftime(current_time, sizeof(current_time), "%H:%M:%S", localtime(&now));
	char *ret_time = static_cast<char *>(malloc(strlen(current_time) + 1));
	sprintf(ret_time, "%s", current_time);
	return ret_time;
}

/**
 * @brief MiMiC DeBooger.
 *
 * A fancy colored Debugger
 *
 * %s%s%s ■ %-*.*s %s => Label
 * %s %s %s           => Timestamp
 * %s %s              => Color Block
 * %s%s %04d %s       => Line Number
 * %s%s%-*.*s %s      => Filename
 * %s %s              => Color Block
 * %s %s" args"%s\n   => Arguments/New Line
 *
 * "%s%s%s ■ %-*.*s %s[-]%s %s %s[-]%s %s[-]%s%s %04d %s[-]%s%s%-*.*s %s[-]%s %s[-] %s %s" args"%s\n",
 */
#define MIMIC_PRINTLN(num, args, ...) \
	printf("%s%s%s ■ %-*.*s %s%s %s %s%s %s%s%s %04d %s%s%s %-*.*s %s%s %s %s" args"%s\n", \
	VT_BOLD, VT_WHITE_FG, \
	LOG_LEVEL[num].vt_bg_color, 7, 7, LOG_LEVEL[num].label, VT_RESET, \
	VT_TIME_BG, get_time(), VT_RESET, \
	LOG_LEVEL[num].vt_bg_color, VT_RESET, \
	VT_LINE_BG, VT_WHITE_FG, __LINE__, VT_RESET, \
	LOG_LEVEL[num].vt_bg_color, VT_WHITE_FG, 15, 15, get_filename_without_path(__FILE__), VT_RESET, \
	LOG_LEVEL[num].vt_bg_color, VT_RESET, \
	LOG_LEVEL[num].vt_fg_color, ##__VA_ARGS__, VT_RESET);

#define LOG_DEBUG(arg, ... )   MIMIC_PRINTLN(0,  arg, ##__VA_ARGS__ );
#define LOG_ERROR(arg, ... )   MIMIC_PRINTLN(1,  arg, ##__VA_ARGS__ );
#define LOG_INFO(arg, ... )    MIMIC_PRINTLN(2,  arg, ##__VA_ARGS__ );
#define LOG_VERBOSE(arg, ... ) MIMIC_PRINTLN(3,  arg, ##__VA_ARGS__ );
#define LOG_WARN(arg, ... )    MIMIC_PRINTLN(4,  arg, ##__VA_ARGS__ );

#define LOG_MIMIC(arg, ... )   MIMIC_PRINTLN(5,  arg, ##__VA_ARGS__ );
#define LOG_CORE(arg, ... )    MIMIC_PRINTLN(6,  arg, ##__VA_ARGS__ );
#define LOG_EVENT(arg, ... )   MIMIC_PRINTLN(7,  arg, ##__VA_ARGS__ );
#define LOG_FPGA(arg, ... )    MIMIC_PRINTLN(8,  arg, ##__VA_ARGS__ );
#define LOG_JTAG(arg, ... )    MIMIC_PRINTLN(8,  arg, ##__VA_ARGS__ );
#define LOG_FS(arg, ... )      MIMIC_PRINTLN(9,  arg, ##__VA_ARGS__ );
#define LOG_I2C(arg, ... )     MIMIC_PRINTLN(10, arg, ##__VA_ARGS__ );
#define LOG_INPUT(arg, ... )   MIMIC_PRINTLN(11, arg, ##__VA_ARGS__ );
#define LOG_NETWORK(arg, ... ) MIMIC_PRINTLN(12, arg, ##__VA_ARGS__ );
#define LOG_OSD(arg, ... )     MIMIC_PRINTLN(13, arg, ##__VA_ARGS__ );
#define LOG_PERIF(arg, ... )   MIMIC_PRINTLN(14, arg, ##__VA_ARGS__ );
#define LOG_SPI(arg, ... )     MIMIC_PRINTLN(15, arg, ##__VA_ARGS__ );
#define LOG_SYSTEM(arg, ... )  MIMIC_PRINTLN(16, arg, ##__VA_ARGS__ );
#define LOG_TIMER(arg, ... )   MIMIC_PRINTLN(17, arg, ##__VA_ARGS__ );
#define LOG_VIDEO(arg, ... )   MIMIC_PRINTLN(18, arg, ##__VA_ARGS__ );
#else
#define LOG_DEBUG(arg, ...)    void();
#define LOG_ERROR(arg, ...)    void();
#define LOG_INFO(arg, ...)     void();
#define LOG_VERBOSE(arg, ...)  void();
#define LOG_WARN(arg, ...)     void();
#define LOG_MIMIC(arg, ...)    void();
#define LOG_CORE(arg, ...)     void();
#define LOG_EVENT(arg, ...)    void();
#define LOG_FPGA(arg, ...)     void();
#define LOG_JTAG(arg, ...)     void();
#define LOG_FS(arg, ...)       void();
#define LOG_I2C(arg, ...)      void();
#define LOG_INPUT(arg, ...)    void();
#define LOG_NETWORK(arg, ...)  void();
#define LOG_OSD(arg, ...)      void();
#define LOG_PERIF(arg, ...)    void();
#define LOG_SPI(arg, ...)      void();
#define LOG_SYSTEM(arg, ...)   void();
#define LOG_TIMER(arg, ...)    void();
#define LOG_VIDEO(arg, ...)    void();
#endif

#ifdef __cplusplus
}
#endif

#endif //MIMIC_DEBUG_H
