/*******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2005-2021, The Raetro authors and contributors
 *******************************************************************************
 *
 * PiSPi
 * Copyright (c) 2005-2021, The Raetro Authors (see AUTHORS file)
 *
 * PiSPi is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the
 * Free Software Foundation, version 3 or (at your option) any later version.
 *
 * PiSPi is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with PiSPi. If not, see <https://www.gnu.org/licenses>.
 *
 ******************************************************************************/

/*!*****************************************************************************
 * @file osd.h
 * @brief 
 ******************************************************************************/

#ifndef PISPI_OSD_H
#define PISPI_OSD_H

#include "stdinc.h"
#include "begin_code.h"
// Set up for C function definitions, even when using C++.
#ifdef __cplusplus
extern "C" {
#endif

#define OSD_TOTAL_LINES   8    /*!< Number of lines of OSD */
#define OSD_LINE_LEN      256  /*!< Single line length in bytes */
#define OSD_HEIGHT        64   /*!< Set OSD Height x8 (max height: 64) */

#define OSD_CMD_WRITE     0x20 /*!< OSD Write Video Data command */
#define OSD_CMD_ENABLE    0x41 /*!< OSD Enable command */
#define OSD_CMD_DISABLE   0x40 /*!< OSD Disable command */

#define OSD_ARROW_LEFT    1    /*!< */
#define OSD_ARROW_RIGHT   2    /*!< */

extern MIMIC_API void osd_set_title(const char *title, int a);
extern MIMIC_API void osd_write(Uint8 n, const char *s, Uint8 invert, Uint8 stipple);
extern MIMIC_API void osd_write_offset(Uint8 n, const char *string, Uint8 inver, Uint8 stipple, char offset);
extern MIMIC_API void osd_clear();
extern MIMIC_API void osd_enable();
extern MIMIC_API void osd_disable();

#ifdef __cplusplus
}
#endif

#include "close_code.h"

#endif //PISPI_OSD_H
