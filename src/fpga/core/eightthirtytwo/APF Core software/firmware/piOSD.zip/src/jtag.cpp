/*******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2005-2021, The Raetro authors and contributors
 *******************************************************************************
 *
 * PiSPI
 * Copyright (c) 2005-2021, The Raetro Authors (see AUTHORS file)
 *
 * PiSPI is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the
 * Free Software Foundation, version 3 or (at your option) any later version.
 *
 * PiSPI is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with PiSPI. If not, see <https://www.gnu.org/licenses>.
 *
 ******************************************************************************/

/*!*****************************************************************************
 * @file jtag.cpp
 * @brief
 *
 * Interface Signals:
 * The JTAG interface, collectively known as a Test Access Port, or TAP, uses
 * the following signals to support the operation of boundary scan.
 * The IEEE standard defines four mandatory TAP signals and one optional TRST signal.
 *
 *  - TCK  (Test Clock) – Synchronizes the internal state machine operations.
 *  - TMS  (Test Mode Select) – Sampled at the rising edge of TCK to determine the next state.
 *  - TDI  (Test Data In) – Represents the data shifted into the device’s test or programming logic.
 *                          It is sampled at the rising edge of TCK when the internal state machine is in the correct state.
 *  - TDO  (Test Data Out) – Represents the data shifted out of the device’s test or programming logic and is valid on the
 *                           falling edge of TCK when the internal state machine is in the correct state.
 *  - TRST (Test Reset) – Optional pin which, when available, can reset the TAP controller’s state machine.
 *
 * Registers:
 * There are two types of registers associated with boundary scan. Each compliant
 * device has one instruction register and two or more data registers.
 *
 * Instruction Register – the instruction register holds the current instruction.
 * Its content is used by the TAP controller to decide what to do with signals
 * that are received. Most commonly, the content of the instruction register will
 * define to which of the data registers signals should be passed.
 *
 * Data Registers – there are three primary data registers, the Boundary Scan
 * Register (BSR), the BYPASS register and the IDCODES register. Other data
 * registers may be present, but they are not required as part of the JTAG standard.
 *
 *  - BSR     – “Boundary-scan register”, main testing data register. It is used to move data to and from the I/O pins of a device.
 *  - BYPASS  – Single-bit register that passes information from TDI to TDO. It allows other devices
 *              in a circuit to be tested with minimal overhead.
 *  - IDCODES – Contains the ID code and revision number for the device. This information allows the device
 *              to be linked to its Boundary Scan Description Language (BSDL) file. The file contains details
 *              of the Boundary Scan configuration for the device.
 *
 *
 * Test Access Port (TAP) Controller
 * The TAP controller, a state machine whose transitions are controlled by the TMS signal, controls the behaviour of the JTAG system.
 *
 * All states have two exits, so all transitions can be controlled by the single TMS signal sampled on TCK.
 * The two main paths allow for setting or retrieving information from either a data register or the instruction register of the device.
 * The data register operated on (e.g. BSR, IDCODES, BYPASS) depends on the value loaded into the instruction register.
 *
 * For more detail on each state, refer to the IEEE 1149.1 Standard JTAG document.
 *
 ******************************************************************************/

#include "mimic.h"
#include "jtag.h"

/**
 * @brief
 */
struct codestr {
	Uint8 onebit: 1;
	Uint32 manuf: 11;
	Uint32 size: 9;
	Uint8 family: 7;
	Uint8 rev: 4;
};

/**
 * @brief
 */
union {
	Uint64 code = 0;
	codestr b;
} idcode;

/**
 * @brief Milliseconds
 * @return Return a number of milliseconds as an unsigned int.
 * Wraps at 49 days.
 */
Uint32 millis() {
	Uint64 epochMilli, now;
	struct timespec ts {};
	clock_gettime(CLOCK_MONOTONIC_RAW, &ts);
	now = (Uint64) ts.tv_sec * (Uint64) 1000 + (Uint64) (ts.tv_nsec / 1000000L);
	return (Uint32) (now - epochMilli);
}

/**
 * @brief Convert bytes to human readable
 * @param bytes
 * @return human-readable version of bytes
 * @example 1048576 -> 1.00 GB
 */
std::string JTAG::bytes_to_human(Uint64 bytes) {
	const char *size_name[] = {"KB", "MB", "GB", "TB"};
	auto final_size = static_cast<double>(bytes);
	size_t size_idx;

	/** Always start with KB */
	final_size /= 1024;
	size_idx = 0;

	while(size_idx < 3 && final_size >= 1024) {
		final_size /= 1024;
		size_idx++;
	}

	char buf[20];
	snprintf(buf, sizeof(buf), "%.2f %s", final_size, size_name[size_idx]);
	return std::string(buf);
}

/**
 * @brief
 * @param bytes
 * @return
 */
const char *JTAG::bytes_to_human_string(Uint64 bytes) {
	char tmp[20], *size;
	sprintf(tmp, "%s", bytes_to_human(bytes).data());
	Uint64 n = strlen(tmp) + 1;
	size = static_cast<char *>(malloc(n));
	strcpy(size, tmp);
	return size;
}

/**
 * @brief
 */
void JTAG::clock() {
	rpi_io_toggle(JTAG_PIN_TCK, HIGH);
	rpi_io_toggle(JTAG_PIN_TCK, LOW);
}

/**
 * @brief Go into reset state
 */
void JTAG::reset() {
	rpi_io_toggle(JTAG_PIN_TMS, HIGH);
	for(int i = 0; i < 10; i++) {
		clock();
	}
}

/**
 * @brief This controller state controls whether to enter the Data Path or the Select-IR-Scan state.
 */
void JTAG::enter_select_dr() {
	rpi_io_toggle(JTAG_PIN_TMS, LOW);
	clock();
	rpi_io_toggle(JTAG_PIN_TMS, HIGH);
	clock();
}

/**
 * @brief In this controller state, the instruction register gets connected between TDI and TDO,
 * and the captured pattern gets shifted on each rising edge of TCK.
 * The instruction available on the TDI pin is also shifted in to the instruction register.
 */
void JTAG::enter_shift_ir() {
	rpi_io_toggle(JTAG_PIN_TMS, HIGH); clock();
	rpi_io_toggle(JTAG_PIN_TMS, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TMS, LOW);  clock();
}

/**
 * @brief These controller states are similar to the Shift-IR,
 * Exit1-IR, Pause-IR, Exit2-IR and Update-IR states in the Instruction path.
 */
void JTAG::enter_shift_dr() {
	rpi_io_toggle(JTAG_PIN_TMS, LOW); clock();
	rpi_io_toggle(JTAG_PIN_TMS, LOW); clock();
}

/**
 * @brief
 */
void JTAG::exit_shift() {
	rpi_io_toggle(JTAG_PIN_TMS, HIGH); clock();
	rpi_io_toggle(JTAG_PIN_TMS, HIGH); clock();
	rpi_io_toggle(JTAG_PIN_TMS, HIGH); clock();
}

/**
 * @brief Read out a sequence of bits from TDO
 * @param bit_length
 * @note: call this function only when in shift-IR or shift-DR state
 */
void JTAG::read_data(int bit_length) {
	int bitofs = 0;
	Uint64 temp;

	bit_length--;
	while(bit_length--) {
		rpi_io_toggle(JTAG_PIN_TCK, HIGH);

		temp = rpi_io_read_lev(JTAG_PIN_TDO);
		temp = temp << bitofs;
		idcode.code |= temp;

		rpi_io_toggle(JTAG_PIN_TCK, LOW);
		bitofs++;
	}

	rpi_io_toggle(JTAG_PIN_TMS, HIGH);
	rpi_io_toggle(JTAG_PIN_TCK, HIGH);

	temp = rpi_io_read_lev(JTAG_PIN_TDO);
	temp = temp << bitofs;
	idcode.code |= temp;

	rpi_io_toggle(JTAG_PIN_TCK, LOW);
	rpi_io_toggle(JTAG_PIN_TMS, HIGH);
	clock();
	rpi_io_toggle(JTAG_PIN_TMS, HIGH);
	clock(); // go back to select-DR
}

/**
 * @brief Read the Data Register
 * @param bit_length
 */
void JTAG::read_dr(int bit_length) {
	enter_shift_dr();
	read_data(bit_length);
}

/**
 * @brief
 * @return
 */
int JTAG::determine_chain_length() {
	int i;
	/** Empty the chain (fill it with 0's) */
	rpi_io_toggle(JTAG_PIN_TDI, LOW);
	for(i = 0; i < MAX_IR_CHAIN_LENGTH; i++) {
		rpi_io_toggle(JTAG_PIN_TMS, LOW);
		clock();
	}
	rpi_io_toggle(JTAG_PIN_TCK, LOW);
	/** Feed the chain with 1's */
	rpi_io_toggle(JTAG_PIN_TDI, HIGH);
	for(i = 0; i < MAX_IR_CHAIN_LENGTH; i++) {
		rpi_io_toggle(JTAG_PIN_TCK, HIGH);
		if(rpi_io_read_lev(JTAG_PIN_TDO) == HIGH) {
			break;
		}
		rpi_io_toggle(JTAG_PIN_TCK, LOW);
	}
	rpi_io_toggle(JTAG_PIN_TCK, LOW);
	exit_shift();

	return i;
}

/**
 * @brief
 */
void JTAG::pre_program() {
	int n;
	reset();
	enter_select_dr();
	enter_shift_ir();
	// Here TMS is already low, no need for another command to lower it
	// IR = PROGRAM   = 00 0000 0010
	// IR = CONFIG_IO = 00 0000 1101
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, HIGH); clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);
	rpi_io_toggle(JTAG_PIN_TMS, HIGH); clock();
	// here exit ir is the current mode
	rpi_io_toggle(JTAG_PIN_TMS, HIGH);
	clock();
	// here update ir is the current mode
	// Drive TDI HIGH while moving to SHIFTDR */
	rpi_io_toggle(JTAG_PIN_TDI, HIGH);
	rpi_io_toggle(JTAG_PIN_TMS, HIGH); clock();
	// here select dr scan is the current mode
	rpi_io_toggle(JTAG_PIN_TMS, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TMS, LOW);  clock();
	// here shift dr is the current mode
	// todo: remove extra call?
	// rpi_io_toggle(JTAG_PIN_TMS, LOW); clock();
	// Issue MAX_JTAG_INIT_CLOCK clocks in SHIFTDR state
	rpi_io_toggle(JTAG_PIN_TDI, HIGH);
	for(n = 0; n < 300; n++) {
		clock();
	}
	rpi_io_toggle(JTAG_PIN_TDI, LOW);
}

/**
 * @brief
 */
void JTAG::post_program() {
	int n;
	// in exit DR
	rpi_io_toggle(JTAG_PIN_TMS, HIGH); clock();
	// in update DR
	rpi_io_toggle(JTAG_PIN_TMS, LOW); clock();
	// in RUN/IDLE
	enter_select_dr();
	enter_shift_ir();
	// in shift ir
	// IR = CHECK STATUS = 00 0000 0100
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, HIGH); clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  //
	rpi_io_toggle(JTAG_PIN_TMS, HIGH); clock();
	// in exit IR
	rpi_io_toggle(JTAG_PIN_TMS, HIGH); clock();
	rpi_io_toggle(JTAG_PIN_TMS, HIGH); clock();
	// in select dr scan
	rpi_io_toggle(JTAG_PIN_TMS, HIGH); clock();
	rpi_io_toggle(JTAG_PIN_TMS, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TMS, LOW);  clock();
	// in shift IR
	// IR = START = 00 0000 0011
	rpi_io_toggle(JTAG_PIN_TDI, HIGH); clock();
	rpi_io_toggle(JTAG_PIN_TDI, HIGH); clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);  clock();
	rpi_io_toggle(JTAG_PIN_TDI, LOW);
	rpi_io_toggle(JTAG_PIN_TMS, HIGH); clock();
	// in exit IR
	rpi_io_toggle(JTAG_PIN_TMS, HIGH); clock();
	rpi_io_toggle(JTAG_PIN_TMS, LOW);  clock();
	// in IDLE
	for(n = 0; n < 200; n++) {
		clock();
	}
	reset();
}

/**
 * @brief Initialize GPIO pins for JTAG
 */
void JTAG::setup() {
	rpi_io_fsel(JTAG_PIN_TCK, RPI_FSEL_OUTP);
	rpi_io_set_pud(JTAG_PIN_TDO, RPI_PUD_UP);
	rpi_io_fsel(JTAG_PIN_TDO, RPI_FSEL_INPT);
	rpi_io_fsel(JTAG_PIN_TMS, RPI_FSEL_OUTP);
	rpi_io_fsel(JTAG_PIN_TDI, RPI_FSEL_OUTP);

	rpi_io_toggle(JTAG_PIN_TCK, LOW);
	rpi_io_toggle(JTAG_PIN_TMS, LOW);
	rpi_io_toggle(JTAG_PIN_TDI, LOW);
}

/**
 * @brief Release GPIO pins and return to it's default state
 */
void JTAG::release() {
	rpi_io_set_pud(JTAG_PIN_TCK, RPI_PUD_DOWN);
	rpi_io_set_pud(JTAG_PIN_TDO, RPI_PUD_DOWN);
	rpi_io_set_pud(JTAG_PIN_TMS, RPI_PUD_UP);
	rpi_io_set_pud(JTAG_PIN_TDI, RPI_PUD_DOWN);
	rpi_io_fsel(JTAG_PIN_TCK, RPI_FSEL_INPT);
	rpi_io_fsel(JTAG_PIN_TDO, RPI_FSEL_INPT);
	rpi_io_fsel(JTAG_PIN_TMS, RPI_FSEL_INPT);
	rpi_io_fsel(JTAG_PIN_TDI, RPI_FSEL_INPT);
}

/**
 * @brief Boundary scan
 * @return
 */
int JTAG::scan() {
	int i, IRlen, nDevices;

	reset();
	enter_select_dr();
	enter_shift_ir();

	IRlen = determine_chain_length();

	enter_shift_dr();
	nDevices = determine_chain_length();

	if(IRlen == MAX_IR_CHAIN_LENGTH || nDevices == MAX_IR_CHAIN_LENGTH) {
		LOG_ERROR("[JTAG] => ERROR!!!!")
		return -1;
	}

	/** IDCODE is 32bit number uniquely identifying part type in JTAG chain. */
	reset();
	enter_select_dr();
	read_dr(32 * nDevices);

	for(i = 0; i < nDevices; i++) {
		LOG_JTAG("[%d] IDCODE       : %" PRId64"", i, idcode.code)
		LOG_JTAG("[%d] Manufacturer : %" PRId8"", i, idcode.b.manuf)
		LOG_JTAG("[%d] Family       : %" PRId32"", i, idcode.b.family)
		LOG_JTAG("[%d] Revision     : %" PRId8"", i, idcode.b.rev)
		LOG_JTAG("[%d] OneBit       : %" PRId8"", i, idcode.b.onebit)
		LOG_JTAG("[%d] Size         : %" PRId32"", i, idcode.b.size)
	}

	return 0;
}

/**
 * @brief
 */
int JTAG::program_fpga(const char *rbf_filename) {
	Uint64 bit_count = 0;
	int n;

	pre_program();

	FILE *fp = fopen(rbf_filename, "rb");
	if(!fp) {
		LOG_ERROR("[JTAG] => Failed to open: %s", rbf_filename);
		return -1;
	}
	fseek(fp, 0L, SEEK_END);
	Uint64 total = ftell(fp);
	rewind(fp);

	while(bit_count < total) { //155224
		Uchar val = fgetc(fp);
		int value;
		bit_count++;
		for(n = 0; n <= 7; n++) {
			value = ((val >> n) & 0x01);
			rpi_io_toggle(JTAG_PIN_TDI, value);
			clock();
		}
	}

	// AKL (Version1.7): Dump additional 16 bytes of 0xFF at the end of the RBF file
	for(n = 0; n < 127; n++) {
		rpi_io_toggle(JTAG_PIN_TDI, HIGH); clock();
	}

	rpi_io_toggle(JTAG_PIN_TDI, HIGH);
	rpi_io_toggle(JTAG_PIN_TMS, HIGH); clock();

	LOG_JTAG("Programmed: %s/%s", bytes_to_human_string(bit_count), bytes_to_human_string(total))

	fclose(fp);
	post_program();
	return 0;
}

/**
 * @brief
 * @param rbf_file
 * @return
 */
int JTAG::load_rbf(const char *rbf_filename) {
	try {
		setup();
		if(scan() == 0) {
			LOG_JTAG("Start Programming...")
			Uint32 startTime = millis();
			Uint32 duration;
			program_fpga(rbf_filename);
			duration = millis() - startTime;
			LOG_JTAG("Done in %i ms", duration)
		}
		release();
		return 0;
	} catch(std::exception &e) {
		LOG_ERROR("Error loading: %s", rbf_filename);
		return -1;
	}
}
