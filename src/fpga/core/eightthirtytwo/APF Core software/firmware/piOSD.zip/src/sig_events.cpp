/*******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2005-2021, The Raetro authors and contributors
 *******************************************************************************
 *
 * MiMiC: Nostalgia Synthesizer Firmware
 * Copyright (c) 2005-2021, The Raetro Authors and contributors (see AUTHORS file)
 *
 * MiMiC NSX is a free software you can redistribute in source and synthesized
 * forms and/or modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation, version 3 or (at your option)
 * any later version.
 *
 * MiMiC NSX is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with the source code. If not, see <https://www.gnu.org/licenses>.
 *
 ******************************************************************************/

/*!*****************************************************************************
 * @file sig_events.cpp
 * @brief Implementation of a generic handler for POSIX signals.
 ******************************************************************************/

#include "mimic.h"
#include "sig_events.h"

/**
 * @brief Handle most common signal events
 * @param sig_num Specifies the signal number to examine or modify.
 * @param sig_ptr Points to a structure that specifies a new signal action.
 * @param sig_void Is a return pointer to a structure for holding the old signal action.
 */
void critical_error_handler(int sig_num, siginfo_t *sig_ptr, void *sig_void) {
	char signal[1000];
	switch (sig_num) {
		case 1:  { sprintf(signal, "%s", LANG_SIGNAL_SIGHUP    );} break;
		case 2:  { sprintf(signal, "%s", LANG_SIGNAL_SIGINT    );} break;
		case 3:  { sprintf(signal, "%s", LANG_SIGNAL_SIGQUIT   );} break;
		case 4:  { sprintf(signal, "%s", LANG_SIGNAL_SIGILL    );} break;
		case 5:  { sprintf(signal, "%s", LANG_SIGNAL_SIGTRAP   );} break;
		case 6:  { sprintf(signal, "%s", LANG_SIGNAL_SIGABRT   );} break;
		case 7:  { sprintf(signal, "%s", LANG_SIGNAL_SIGBUS    );} break;
		case 8:  { sprintf(signal, "%s", LANG_SIGNAL_SIGFPE    );} break;
		case 9:  { sprintf(signal, "%s", LANG_SIGNAL_SIGKILL   );} break;
		case 10: { sprintf(signal, "%s", LANG_SIGNAL_SIGUSR1   );} break;
		case 11: { sprintf(signal, "%s", LANG_SIGNAL_SIGSEGV   );} break;
		case 12: { sprintf(signal, "%s", LANG_SIGNAL_SIGUSR2   );} break;
		case 13: { sprintf(signal, "%s", LANG_SIGNAL_SIGPIPE   );} break;
		case 14: { sprintf(signal, "%s", LANG_SIGNAL_SIGALRM   );} break;
		case 15: { sprintf(signal, "%s", LANG_SIGNAL_SIGTERM   );} break;
		case 16: { sprintf(signal, "%s", LANG_SIGNAL_SIGSTKFLT );} break;
		case 17: { sprintf(signal, "%s", LANG_SIGNAL_SIGCHLD   );} break;
		default :{ sprintf(signal, "%s", LANG_SIGNAL_SIGUNKNOWN);} break;
	}
	printf("The application has crashed.\n");
	printf("SIG Code: %d\n", sig_num);
	printf("%s\n", signal);
	exit(sig_num);
}

/**
 * @brief Initialize SIG events
 */
void init_sigterm() {
	struct sigaction sa{};
	memset(&sa, 0, sizeof(struct sigaction));
	sigemptyset(&sa.sa_mask);
	sa.sa_sigaction = critical_error_handler;
	sa.sa_flags = SA_SIGINFO;
	sigaction(SIGABRT  , &sa, nullptr);
	sigaction(SIGALRM  , &sa, nullptr);
	sigaction(SIGBUS   , &sa, nullptr);
	sigaction(SIGFPE   , &sa, nullptr);
	sigaction(SIGHUP   , &sa, nullptr);
	sigaction(SIGILL   , &sa, nullptr);
	sigaction(SIGINT   , &sa, nullptr);
	sigaction(SIGIOT   , &sa, nullptr);
	sigaction(SIGKILL  , &sa, nullptr);
	sigaction(SIGPIPE  , &sa, nullptr);
	sigaction(SIGQUIT  , &sa, nullptr);
	sigaction(SIGSEGV  , &sa, nullptr);
	sigaction(SIGSTKFLT, &sa, nullptr);
	sigaction(SIGTERM  , &sa, nullptr);
	sigaction(SIGTRAP  , &sa, nullptr);
	sigaction(SIGUSR1  , &sa, nullptr);
	sigaction(SIGUSR2  , &sa, nullptr);
	signal(SIGTERM, &handle_sigterm);
}

/**
 * @brief Handles SIGTERM sent by the OS
 * @param sig_num Signal number
 */
void handle_sigterm(int sig_num) {
	printf("SIGTERM Received\n");
	app_initialized = 0;
	if(sig_num) {
		critical_error_handler(sig_num, nullptr, nullptr);
		printf("%s\n", LANG_SIGNAL_GOODBYE);
	}
}
