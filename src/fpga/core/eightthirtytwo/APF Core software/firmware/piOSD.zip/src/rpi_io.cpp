/*******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2005-2021, The Raetro authors and contributors
 *******************************************************************************
 *
 * PiSPi
 * Copyright (c) 2005-2021, The Raetro Authors (see AUTHORS file)
 *
 * PiSPi is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the
 * Free Software Foundation, version 3 or (at your option) any later version.
 *
 * PiSPi is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with PiSPi. If not, see <https://www.gnu.org/licenses>.
 *
 ******************************************************************************/

/*!*****************************************************************************
 * @file rpi_io.cpp
 * @brief Implementation of I/O Controller using Raspberry PI MMIO (Memory Mapped IO).
 *
 * | Name                  |  Pin  |  Pin  | Name                  |
 * | --------------------- | ----- | ----- | --------------------- |
 * | 3.3v DC Power         | 01[+] | 02[+] | 5v DC Power           |
 * | GPIO02 (SDA1, I2C)    | 03[H] | 04[+] | 5v DC Power           |
 * | GPIO03 (SCL1, I2C)    | 05[H] | 06[-] | Ground                |
 * | GPIO04 (GPIO_GCLK)    | 07[H] | 08[L] | GPIO14 (TXD0)         |
 * | Ground                | 09[-] | 10[L] | GPIO15 (RXD0)         |
 * | GPIO17 (GPIO_GEN0)    | 11[L] | 12[L] | GPIO18 (GPIO_GEN1)    |
 * | GPIO27 (GPIO_GEN2)    | 13[L] | 14[-] | Ground                |
 * | GPIO22 (GPIO_GEN3)    | 15[L] | 16[L] | GPIO23 (GPIO_GEN4)    |
 * | 3.3v DC Power         | 17[+] | 18[L] | GPIO24 (GPIO_GEN5)    |
 * | GPIO10 (SPI_MOSI)     | 19[L] | 20[-] | Ground                |
 * | GPIO09 (SPI_MISO)     | 21[L] | 22[L] | GPIO25 (GPIO_GEN6)    |
 * | GPIO11 (SPI_CLK)      | 23[L] | 24[H] | GPIO08 (SPI_CE0_N)    |
 * | Ground                | 25[-] | 26[H] | GPIO07 (SPI_CE1_N)    |
 * | ID_SD (I2C ID EEPROM) | 27[R] | 28[R] | ID_SC (I2C ID EEPROM) |
 * | GPIO05                | 29[L] | 30[-] | Ground                |
 * | GPIO06                | 31[L] | 32[L] | GPIO12                |
 * | GPIO13                | 33[L] | 34[-] | Ground                |
 * | GPIO19                | 35[L] | 36[L] | GPIO16                |
 * | GPIO26                | 37[L] | 38[L] | GPIO20                |
 * | Ground                | 39[-] | 40[L] | GPIO21                |
 *
 ******************************************************************************/

#include "mimic.h"

Uint32 *map_base = (Uint32 *) MAP_FAILED;
volatile Uint32 *pi_gpio = (Uint32 *) MAP_FAILED;
volatile Uint32 *pi_spi0 = (Uint32 *) MAP_FAILED;
volatile Uint32 *pi_st = (Uint32 *) MAP_FAILED;

Uint8 pud_type_rpi4 = 0; /*!< RPI 4 pullup registers */
Uint8 pud_compat_setting = RPI_PUD_OFF; /*!< RPI 4 back-compat for pullup operation */

/**
 * @brief Delay function for milliseconds
 * @param[in] millis How many milliseconds
 */
void delay(unsigned int millis) {
	struct timespec sleeper {};
	sleeper.tv_sec = (time_t) (millis / 1000);
	sleeper.tv_nsec = (long) (millis % 1000) * 1000000;
	nanosleep(&sleeper, nullptr);
}

/**
 * @brief Delay function for microseconds
 * @param[in] micros How many microseconds
 */
void delayMicroseconds(Uint64 micros) {
	struct timespec t1 {};
	Uint64 start;
	/** Calling nanosleep() takes at least 100-200 us, so use it for long waits and use a busy wait on the System Timer for the rest. */
	start = rpi_st_read();
	/** Not allowed to access timer registers (result is not as precise) */
	if(start == 0) {
		t1.tv_sec = 0;
		t1.tv_nsec = 1000 * (long) (micros);
		nanosleep(&t1, nullptr);
		return;
	}
	if(micros > 450) {
		t1.tv_sec = 0;
		t1.tv_nsec = 1000 * (long) (micros - 200);
		nanosleep(&t1, nullptr);
	}
	rpi_st_delay(start, micros);
}

/**
 * @brief
 */
void prevent_linux_swapping() {
	struct sched_param sp {};
	memset(&sp, 0, sizeof(sp));
	sp.sched_priority = sched_get_priority_max(SCHED_FIFO);
	sched_setscheduler(0, SCHED_FIFO, &sp);
	mlockall(MCL_CURRENT | MCL_FUTURE);
}

/**
 * @brief Initialize RPI.
 * Creates a memory mapped region of the ARM Peripherals
 *
 * @return 0 on success, -1 on error.
 */
int rpi_io_init() {
	int fd;

	if((fd = open("/dev/mem", O_RDWR | O_SYNC)) < 0) {
		LOG_ERROR("Failed to open /dev/mem, try checking permissions.")
		return -1;
	}

	map_base = (Uint32 *) mmap(nullptr, RPI_REG_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, RPI_REG_BASE);
	close(fd);

	if(map_base == MAP_FAILED) {
		LOG_ERROR("Unable to mmap(/dev/mem)")
		return -1;
	}

	/** @note map_base is Uint32*, so divide offsets by 4 */
	pi_gpio = map_base + RPI_GPIO_BASE / 4;
	pi_spi0 = map_base + RPI_SPI0_BASE / 4;
	pi_st = map_base + RPI_ST_BASE / 4;

	#ifdef RPI_2711
	pud_type_rpi4 = 1;
	#endif

	prevent_linux_swapping();
	app_initialized = 1;
	return 0;
}

void rpi_io_close() {
	munmap(map_base, RPI_REG_SIZE);
}

/////////////////////////////////////////////////////////////////////////

/**
 * @brief Read the System Timer Counter (64-bits)
 * @return
 */
Uint64 rpi_st_read() {
	volatile Uint32 *paddr;
	Uint32 hi, lo;
	Uint64 st;

	if(pi_st == MAP_FAILED) {
		return 0;
	}

	paddr = pi_st + RPI_ST_CHI / 4;
	hi = rpi_io_read(paddr);

	paddr = pi_st + RPI_ST_CLO / 4;
	lo = rpi_io_read(paddr);

	paddr = pi_st + RPI_ST_CHI / 4;
	st = rpi_io_read(paddr);

	/* Test for overflow */
	if(st == hi) {
		st <<= 32;
		st += lo;
	} else {
		st <<= 32;
		paddr = pi_st + RPI_ST_CLO / 4;
		st += rpi_io_read(paddr);
	}
	return st;
}

/**
 * @brief Delays for the specified number of microseconds with offset
 * @param offset_micros
 * @param micros
 */
void rpi_st_delay(Uint64 offset_micros, Uint64 micros) {
	Uint64 compare = offset_micros + micros;

	while (rpi_st_read() < compare) {}
}

/////////////////////////////////////////////////////////////////////////

/**
 * @brief Read with memory barriers from peripheral
 * @param paddr
 * @return
 */
Uint32 rpi_io_read(const volatile Uint32 *paddr) {
	Uint32 ret;
	__sync_synchronize();
	ret = *paddr;
	__sync_synchronize();
	return ret;
}

/**
 * @brief read from peripheral without the read barrier
 * This can only be used if more reads to THE SAME peripheral
 * will follow. The sequence must terminate with memory barrier
 * before any read or write to another peripheral can occur.
 * The MB can be explicit, or one of the barrier read/write calls.
 * @param paddr
 * @return
 */
Uint32 rpi_io_read_nb(const volatile Uint32 *paddr) {
	return *paddr;
}

/**
 * @brief Write with memory barriers to peripheral
 * @param paddr
 * @param value
 */
void rpi_io_write(volatile Uint32 *paddr, Uint32 value) {
	__sync_synchronize();
	*paddr = value;
	__sync_synchronize();
}

/**
 * @brief Write to peripheral without the write barrier
 * @param paddr
 * @param value
 */
void rpi_io_write_nb(volatile Uint32 *paddr, Uint32 value) {
	*paddr = value;
}

/**
 * @brief Set/clear only the bits in value covered by the mask
 * @param paddr
 * @param value
 * @param mask
 * @note Can be interrupted (not atomic).
 */
void rpi_io_set_bits(volatile Uint32 *paddr, Uint32 value, Uint32 mask) {
	Uint32 io_read = rpi_io_read(paddr);
	io_read = (io_read & ~mask) | (value & mask);
	rpi_io_write(paddr, io_read);
}

/**
 * @brief GPIO Function Selection
 *
 * Function selects are 10 pins per 32 bit word, 3 bits per pin
 *
 * There are 6 control registers, each control the functions of a block of 10 pins.
 * Each control register has 10 sets of 3 bits per GPIO pin:
 * 000 = Input
 * 001 = Output
 * 100 = Alternate Function 0
 * 101 = Alternate Function 1
 * 110 = Alternate Function 2
 * 111 = Alternate Function 3
 * 011 = Alternate Function 4
 * 010 = Alternate Function 5
 *
 * So the 3 bits for port X is: X / 10 + ((X % 10) * 3)
 *
 * @param[in] pin BCM GPIO pin number NOT RPi pin number
 * @param[in] mode
 */
void rpi_io_fsel(Uint8 pin, Uint8 mode) {
	volatile Uint32 *paddr = pi_gpio + RPI_GPFSEL0 / 4 + (pin / 10);
	Uint8 shift = (pin % 10) * 3;
	Uint32 mask = RPI_FSEL_MASK << shift;
	Uint32 value = mode << shift;
	rpi_io_set_bits(paddr, value, mask);
}

/**
 * @brief Set output pin
 * @param[in] pin BCM GPIO pin number NOT RPi pin number
 */
void rpi_io_set(Uint8 pin) {
	volatile Uint32 *paddr = pi_gpio + RPI_GPSET0 / 4 + pin / 32;
	Uint8 shift = pin % 32;
	rpi_io_write(paddr, 1 << shift);
}

/**
 * @brief Clear output pin
 * @param[in] pin BCM GPIO pin number NOT RPi pin number
 */
void rpi_io_clear(Uint8 pin) {
	volatile Uint32 *paddr = pi_gpio + RPI_GPCLR0 / 4 + pin / 32;
	Uint8 shift = pin % 32;
	rpi_io_write(paddr, 1 << shift);
}

/**
 * @brief Toggle the state of an output
 * @param pin
 * @param on
 */
void rpi_io_toggle(Uint8 pin, Uint8 on) {
	if(on) {
		rpi_io_set(pin);
	} else {
		rpi_io_clear(pin);
	}
}

/**
 * @brief Set pullup/down
 * @param pud
 */
void rpi_io_pud(Uint8 pud) {
	if(pud_type_rpi4) {
		pud_compat_setting = pud;
	} else {
		volatile Uint32 *paddr = pi_gpio + RPI_GPPUD / 4;
		rpi_io_write(paddr, pud);
	}
}

/**
 * @brief Pullup/down clock
 * Clocks the value of pud into the GPIO pin
 * @param pin
 * @param on
 */
void rpi_io_pudclk(Uint8 pin, Uint8 on) {
	if(pud_type_rpi4) {
		if(on) {
			rpi_io_set_pud(pin, pud_compat_setting);
		}
	} else {
		volatile Uint32 *paddr = pi_gpio + RPI_GPPUDCLK0 / 4 + pin / 32;
		Uint8 shift = pin % 32;
		rpi_io_write(paddr, (on ? 1 : 0) << shift);
	}
}

/**
 * @brief Set the pullup/down resistor for a pin
 *
 * The GPIO Pull-up/down Clock Registers control the actuation of internal pull-downs on
 * the respective GPIO pins. These registers must be used in conjunction with the GPPUD
 * register to effect GPIO Pull-up/down changes.
 *
 * The following sequence of events is required:
 * 1. Write to GPPUD to set the required control signal (i.e. Pull-up or Pull-Down or neither to remove the current Pull-up/down)
 * 2. Wait 150 cycles ? this provides the required set-up time for the control signal
 * 3. Write to GPPUDCLK0/1 to clock the control signal into the GPIO pads you wish to modify?
 * NOTE only the pads which receive a clock will be modified, all others will retain their previous state.
 * 4. Wait 150 cycles ? this provides the required hold time for the control signal
 * 5. Write to GPPUD to remove the control signal
 * 6. Write to GPPUDCLK0/1 to remove the clock
 *
 * RPi has P1-03 and P1-05 with 1k8 pullup resistor
 * RPI 4 uses a different PUD method - no clock
 */
void rpi_io_set_pud(Uint8 pin, Uint8 pud) {
	if(pud_type_rpi4) {
		int shift_bits = (pin & 0xf) << 1;
		Uint32 bits;
		Uint32 pull;

		switch (pud) {
			case RPI_PUD_OFF:  { pull = 0; } break;
			case RPI_PUD_UP:   { pull = 1; } break;
			case RPI_PUD_DOWN: { pull = 2; } break;
			default: return;
		}

		volatile Uint32 *paddr = pi_gpio + RPI_GPPUPPDN0 / 4 + (pin >> 4);

		bits = rpi_io_read_nb(paddr);
		bits &= ~(3 << shift_bits);
		bits |= (pull << shift_bits);

		rpi_io_write_nb(paddr, bits);
	} else {
		rpi_io_pud(pud);
		delayMicroseconds(10);
		rpi_io_pudclk(pin, 1);
		delayMicroseconds(10);
		rpi_io_pud(RPI_PUD_OFF);
		rpi_io_pudclk(pin, 0);
	}
}

/**
 * @brief On the BCM2711 based RPI 4, gets the current Pull-up/down mode for the specified pin.
 * @param[in] pin GPIO number
 * @return Returns one of RPI_PUD_* from RPI_PUD_CRTL
 * On earlier RPI versions not based on the BCM2711, returns RPI_PUD_ERROR
 */
Uint8 rpi_io_get_pud(Uint8 pin) {
	Uint8 ret = RPI_PUD_ERROR;
	if(pud_type_rpi4) {
		Uint32 bits;
		volatile Uint32 *paddr = pi_gpio + RPI_GPPUPPDN0 / 4 + (pin >> 4);
		bits = (rpi_io_read_nb(paddr) >> ((pin & 0xf) << 1)) & 0x3;
		switch (bits) {
			case 0: { ret = RPI_PUD_OFF; }  break;
			case 1: { ret = RPI_PUD_UP; }   break;
			case 2: { ret = RPI_PUD_DOWN; } break;
			default: ret = RPI_PUD_ERROR;
		}
	}

	return ret;
}

/**
 * @brief Reads the current level on the specified pin and returns either HIGH or LOW.
 * Works whether or not the pin is an input or an output.
 * @param[in] pin GPIO number
 * @return the current level  either HIGH or LOW
 */
Uint8 rpi_io_read_lev(Uint8 pin) {
	volatile Uint32 *paddr = pi_gpio + RPI_GPLEV0 / 4 + pin / 32;
	Uint8 shift = pin % 32;
	Uint32 value = rpi_io_read(paddr);
	return (value & (1 << shift)) ? HIGH : LOW;
}

/////////////////////////////////////////////////////////////

#define LED_PIN 26

void set_disk_led() {
	rpi_io_fsel(LED_PIN, RPI_FSEL_OUTP);
}

void toggle_disk_led(bool on) {
	if(on) {
		rpi_io_toggle(LED_PIN, HIGH);
	} else {
		rpi_io_toggle(LED_PIN, LOW);
	}
}

/////////////////////////////////////////////////////////////

static Uint8 rpi_spi_bit_order = RPI_SPI_MSBFIRST;

/**
 * @brief Set Default Behaviour
 */
void rpi_spi_set_default() {
	rpi_io_spi_set_bit_order(RPI_SPI_MSBFIRST);
	rpi_io_spi_set_data_mode(RPI_SPI_MODE0); //Data comes in on falling edge
	rpi_spi_set_clock_divider(RPI_SPI_CLOCK_DIVIDER_16);
	rpi_io_spi_chip_select(RPI_SPI_CS_NONE);
}

int rpi_io_spi_init() {
	volatile Uint32 *paddr;

	if(pi_spi0 == MAP_FAILED) {
		return 0;
	}

	/* Set the SPI0 pins to the Alt 0 function to enable SPI0 access on them */
	rpi_io_fsel(SPI_PIN_CE1, RPI_FSEL_ALT0);  /* CE1  */
	rpi_io_fsel(SPI_PIN_CE0, RPI_FSEL_ALT0);  /* CE0  */
	rpi_io_fsel(SPI_PIN_MISO, RPI_FSEL_ALT0); /* MISO */
	rpi_io_fsel(SPI_PIN_MOSI, RPI_FSEL_ALT0); /* MOSI */
	rpi_io_fsel(SPI_PIN_SCLK, RPI_FSEL_ALT0); /* SCLK */

	/* Set the SPI CS register to the same sensible defaults */
	paddr = pi_spi0 + RPI_SPI0_CS / 4;
	rpi_io_write(paddr, 0); /* All 0s */

	/* Clear TX and RX FIFOs */
	rpi_io_write_nb(paddr, RPI_SPI0_CS_CLEAR);

	return 1; // OK
}

/**
 * @brief Set all the SPI0 pins back to input
 */
void rpi_io_spi_reset() {
	rpi_io_fsel(SPI_PIN_CE1, RPI_FSEL_INPT); /* CE1  */
	rpi_io_fsel(SPI_PIN_CE0, RPI_FSEL_INPT); /* CE0  */
	rpi_io_fsel(SPI_PIN_MISO, RPI_FSEL_INPT); /* MISO */
	rpi_io_fsel(SPI_PIN_MOSI, RPI_FSEL_INPT); /* MOSI */
	rpi_io_fsel(SPI_PIN_SCLK, RPI_FSEL_INPT); /* CLK  */
}

/**
 * @brief Look up table to reverse bytes
 */
static Uint8 rpi_byte_reverse_lut[] = {
	0x00, 0x80, 0x40, 0xc0, 0x20, 0xa0, 0x60, 0xe0, 0x10, 0x90, 0x50, 0xd0, 0x30, 0xb0, 0x70, 0xf0, 0x08, 0x88, 0x48, 0xc8, 0x28, 0xa8, 0x68, 0xe8, 0x18, 0x98, 0x58, 0xd8, 0x38,
	0xb8, 0x78, 0xf8, 0x04, 0x84, 0x44, 0xc4, 0x24, 0xa4, 0x64, 0xe4, 0x14, 0x94, 0x54, 0xd4, 0x34, 0xb4, 0x74, 0xf4, 0x0c, 0x8c, 0x4c, 0xcc, 0x2c, 0xac, 0x6c, 0xec, 0x1c, 0x9c,
	0x5c, 0xdc, 0x3c, 0xbc, 0x7c, 0xfc, 0x02, 0x82, 0x42, 0xc2, 0x22, 0xa2, 0x62, 0xe2, 0x12, 0x92, 0x52, 0xd2, 0x32, 0xb2, 0x72, 0xf2, 0x0a, 0x8a, 0x4a, 0xca, 0x2a, 0xaa, 0x6a,
	0xea, 0x1a, 0x9a, 0x5a, 0xda, 0x3a, 0xba, 0x7a, 0xfa, 0x06, 0x86, 0x46, 0xc6, 0x26, 0xa6, 0x66, 0xe6, 0x16, 0x96, 0x56, 0xd6, 0x36, 0xb6, 0x76, 0xf6, 0x0e, 0x8e, 0x4e, 0xce,
	0x2e, 0xae, 0x6e, 0xee, 0x1e, 0x9e, 0x5e, 0xde, 0x3e, 0xbe, 0x7e, 0xfe, 0x01, 0x81, 0x41, 0xc1, 0x21, 0xa1, 0x61, 0xe1, 0x11, 0x91, 0x51, 0xd1, 0x31, 0xb1, 0x71, 0xf1, 0x09,
	0x89, 0x49, 0xc9, 0x29, 0xa9, 0x69, 0xe9, 0x19, 0x99, 0x59, 0xd9, 0x39, 0xb9, 0x79, 0xf9, 0x05, 0x85, 0x45, 0xc5, 0x25, 0xa5, 0x65, 0xe5, 0x15, 0x95, 0x55, 0xd5, 0x35, 0xb5,
	0x75, 0xf5, 0x0d, 0x8d, 0x4d, 0xcd, 0x2d, 0xad, 0x6d, 0xed, 0x1d, 0x9d, 0x5d, 0xdd, 0x3d, 0xbd, 0x7d, 0xfd, 0x03, 0x83, 0x43, 0xc3, 0x23, 0xa3, 0x63, 0xe3, 0x13, 0x93, 0x53,
	0xd3, 0x33, 0xb3, 0x73, 0xf3, 0x0b, 0x8b, 0x4b, 0xcb, 0x2b, 0xab, 0x6b, 0xeb, 0x1b, 0x9b, 0x5b, 0xdb, 0x3b, 0xbb, 0x7b, 0xfb, 0x07, 0x87, 0x47, 0xc7, 0x27, 0xa7, 0x67, 0xe7,
	0x17, 0x97, 0x57, 0xd7, 0x37, 0xb7, 0x77, 0xf7, 0x0f, 0x8f, 0x4f, 0xcf, 0x2f, 0xaf, 0x6f, 0xef, 0x1f, 0x9f, 0x5f, 0xdf, 0x3f, 0xbf, 0x7f, 0xff
};

/**
 * @brief
 * @param b
 * @return
 */
Uint8 rpi_io_correct_order(Uint8 b) {
	return rpi_spi_bit_order == RPI_SPI_LSBFIRST ? rpi_byte_reverse_lut[b] : b;
}

/**
 * @brief
 * @param order
 */
void rpi_io_spi_set_bit_order(Uint8 order) {
	rpi_spi_bit_order = order;
}

/**
 * @brief The divisor must be a power of 2. Odd numbers rounded down.
 * The maximum SPI clock rate is of the APB clock
 * @param divider defaults to 0, which means a divider of 65536.
 */
void rpi_spi_set_clock_divider(Uint16 divider) {
	volatile Uint32 *paddr = pi_spi0 + RPI_SPI0_CLK / 4;
	rpi_io_write(paddr, divider);
}

/**
 * @brief
 * @param speed_hz
 */
void rpi_io_spi_set_speed_hz(Uint32 speed_hz) {
	auto divider = (Uint16) ((Uint32) RPI_CORE_CLK_HZ / speed_hz);
	divider &= 0xFFFE;
	rpi_spi_set_clock_divider(divider);
}

/**
 * @brief Mask in the CPO and CPHA bits of CS
 * @param mode
 */
void rpi_io_spi_set_data_mode(Uint8 mode) {
	volatile Uint32 *paddr = pi_spi0 + RPI_SPI0_CS / 4;
	rpi_io_set_bits(paddr, mode << 2, RPI_SPI0_CS_CPOL | RPI_SPI0_CS_CPHA);
}

/**
 * @brief Writes (and reads) a single byte to SPI
 * @param value
 * @return
 */
Uint8 rpi_io_spi_transfer(Uint8 value) {
	volatile Uint32 *paddr = pi_spi0 + RPI_SPI0_CS / 4;
	volatile Uint32 *fifo = pi_spi0 + RPI_SPI0_FIFO / 4;
	Uint32 ret;
	/** Clear TX and RX FIFOs */
	rpi_io_set_bits(paddr, RPI_SPI0_CS_CLEAR, RPI_SPI0_CS_CLEAR);
	/** Set TA = 1 */
	rpi_io_set_bits(paddr, RPI_SPI0_CS_TA, RPI_SPI0_CS_TA);
	/** Maybe wait for TXD */
	while(!(rpi_io_read(paddr) & RPI_SPI0_CS_TXD)) {
	}
	/** Write to FIFO, no barrier */
	rpi_io_write_nb(fifo, rpi_io_correct_order(value));
	/** Wait for DONE to be set */
	while(!(rpi_io_read_nb(paddr) & RPI_SPI0_CS_DONE)) {
	}
	/** Read any byte that was sent back by the slave while we sere sending to it */
	ret = rpi_io_correct_order(rpi_io_read_nb(fifo));
	/** Set TA = 0, and also set the barrier */
	rpi_io_set_bits(paddr, 0, RPI_SPI0_CS_TA);

	return ret;
}

/**
 * @brief Writes (and reads) an number of bytes to SPI
 * Transfers any number of bytes to and from the currently selected SPI slave.
 * Asserts the currently selected CS pins (as previously set by rpi_io_spi_chipSelect)
 * during the transfer.
 * Clocks the len 8 bit bytes out on MOSI, and simultaneously clocks in data from MISO.
 * The data read read from the slave is placed into rbuf. rbuf must be at least len bytes long
 * Uses polled transfer as per section 10.6.1 of the BCM 2835 ARM Peripherals manual
 *
 * @param[in] tx_buf Buffer of bytes to send.
 * @param[out] rx_buf Received bytes will by put in this buffer
 * @param[in] len Number of bytes in the tx_buf buffer, and the number of bytes to send/received
 * @note This is Polled transfer as per section 10.6.1
 * BUG ALERT: what happens if we get interrupted in this section, and someone else accesses a different peripheral?
 */
void rpi_io_spi_transfernb(char *tx_buf, char *rx_buf, Uint32 len) {
	volatile Uint32 *paddr = pi_spi0 + RPI_SPI0_CS / 4;
	volatile Uint32 *fifo = pi_spi0 + RPI_SPI0_FIFO / 4;
	Uint32 TXCnt = 0;
	Uint32 RXCnt = 0;
	/** Clear TX and RX fifos */
	rpi_io_set_bits(paddr, RPI_SPI0_CS_CLEAR, RPI_SPI0_CS_CLEAR);
	/** Set TA = 1 */
	rpi_io_set_bits(paddr, RPI_SPI0_CS_TA, RPI_SPI0_CS_TA);
	/** Use the FIFO's to reduce the interbyte times */
	while((TXCnt < len) || (RXCnt < len)) {
		/** TX fifo not full, so add some more bytes */
		while(((rpi_io_read(paddr) & RPI_SPI0_CS_TXD)) && (TXCnt < len)) {
			rpi_io_write_nb(fifo, rpi_io_correct_order(tx_buf[TXCnt]));
			TXCnt++;
		}
		/** Rx fifo not empty, so get the next received bytes */
		while(((rpi_io_read(paddr) & RPI_SPI0_CS_RXD)) && (RXCnt < len)) {
			rx_buf[RXCnt] = (char) rpi_io_correct_order(rpi_io_read_nb(fifo));
			RXCnt++;
		}
	}
	/** Wait for DONE to be set */
	while(!(rpi_io_read_nb(paddr) & RPI_SPI0_CS_DONE)) {
	}
	/** Set TA = 0, and also set the barrier */
	rpi_io_set_bits(paddr, 0, RPI_SPI0_CS_TA);
}

/**
 * @brief Writes (and reads) an number of bytes to SPI
 * The returned data from the slave replaces the transmitted data in the buffer.
 * @param[in,out] buf Buffer of bytes to send. Received bytes will replace the contents
 * @param[in] len Number of bytes in the buffer, and the number of bytes to send/received
 */
void rpi_io_spi_transfern(char *buf, Uint32 len) {
	rpi_io_spi_transfernb(buf, buf, len);
}

/**
 * @brief Writes a single byte to SPI
 * @param data
 */
void rpi_io_spi_write(Uint16 data) {
	volatile Uint32 *paddr = pi_spi0 + RPI_SPI0_CS / 4;
	volatile Uint32 *fifo = pi_spi0 + RPI_SPI0_FIFO / 4;
	/** Clear TX and RX FIFOs */
	rpi_io_set_bits(paddr, RPI_SPI0_CS_CLEAR, RPI_SPI0_CS_CLEAR);
	/** Set TA = 1 */
	rpi_io_set_bits(paddr, RPI_SPI0_CS_TA, RPI_SPI0_CS_TA);
	/** Maybe wait for TXD */
	while(!(rpi_io_read(paddr) & RPI_SPI0_CS_TXD)) {
	}
	/** Write to FIFO */
	rpi_io_write_nb(fifo, (Uint32) data >> 8);
	rpi_io_write_nb(fifo, data & 0xFF);
	/** Wait for DONE to be set */
	while(!(rpi_io_read_nb(paddr) & RPI_SPI0_CS_DONE)) {
	}
	/** Set TA = 0, and also set the barrier */
	rpi_io_set_bits(paddr, 0, RPI_SPI0_CS_TA);
}

/**
 * @brief Writes an number of bytes to SPI
 * @param tbuf
 * @param len
 *
 * This is Polled transfer as per section 10.6.1
 * BUG ALERT: what happens if we get interrupted in this section, and someone else accesses a different peripheral?
 * an ISR is required to issue the required memory barriers.
 */
void rpi_io_spi_writenb(const char *tbuf, Uint32 len) {
	volatile Uint32 *paddr = pi_spi0 + RPI_SPI0_CS / 4;
	volatile Uint32 *fifo = pi_spi0 + RPI_SPI0_FIFO / 4;
	Uint32 i;
	/** Clear TX and RX fifos */
	rpi_io_set_bits(paddr, RPI_SPI0_CS_CLEAR, RPI_SPI0_CS_CLEAR);
	/** Set TA = 1 */
	rpi_io_set_bits(paddr, RPI_SPI0_CS_TA, RPI_SPI0_CS_TA);
	for(i = 0; i < len; i++) {
		/** Maybe wait for TXD */
		while(!(rpi_io_read(paddr) & RPI_SPI0_CS_TXD)) {
		}
		/** Write to FIFO, no barrier */
		rpi_io_write_nb(fifo, rpi_io_correct_order(tbuf[i]));
		/** Read from FIFO to prevent stalling */
		while(rpi_io_read(paddr) & RPI_SPI0_CS_RXD) {
			(void) rpi_io_read_nb(fifo);
		}
	}
	/** Wait for DONE to be set */
	while(!(rpi_io_read_nb(paddr) & RPI_SPI0_CS_DONE)) {
		while(rpi_io_read(paddr) & RPI_SPI0_CS_RXD) {
			(void) rpi_io_read_nb(fifo);
		}
	}
	/** Set TA = 0, and also set the barrier */
	rpi_io_set_bits(paddr, 0, RPI_SPI0_CS_TA);
}

/**
 * @brief Mask in the CS bits of CS
 * @param cs
 */
void rpi_io_spi_chip_select(Uint8 cs) {
	volatile Uint32 *paddr = pi_spi0 + RPI_SPI0_CS / 4;
	rpi_io_set_bits(paddr, cs, RPI_SPI0_CS_CS);
}

/**
 * @brief Mask in the appropriate CSPOLn bit
 * @param cs
 * @param active
 */
void rpi_io_spi_set_cs_polarity(Uint8 cs, Uint8 active) {
	volatile Uint32 *paddr = pi_spi0 + RPI_SPI0_CS / 4;
	Uint8 shift = 21 + cs;
	rpi_io_set_bits(paddr, active << shift, 1 << shift);
}

