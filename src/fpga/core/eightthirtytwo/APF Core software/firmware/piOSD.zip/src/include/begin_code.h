/*******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2005-2021, The Raetro authors and contributors
 *******************************************************************************
 *
 * PiSPi
 * Copyright (c) 2005-2021, The Raetro Authors (see AUTHORS file)
 *
 * PiSPi is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the
 * Free Software Foundation, version 3 or (at your option) any later version.
 *
 * PiSPi is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with PiSPi. If not, see <https://www.gnu.org/licenses>.
 *
 ******************************************************************************/

/*!*****************************************************************************
 * @file begin_code.h
 * @brief Interface of C dynamic libraries.
 *
 * This file sets things up for C dynamic library function definitions,
 * static inline functions, and structures aligned at 4-byte alignment.
 ******************************************************************************/

#ifdef BEGIN_CODE_H
#error Nested inclusion of begin_code.h
#endif

/**
 * Header Definition
 */
#define BEGIN_CODE_H

/**
 * By default MiMiC uses the C calling convention
 */
#ifndef MIMIC_CALLCONV
#define MIMIC_CALLCONV
#endif // MIMIC_CALLCONV

/**
 * Some compilers use a special export keyword
 */
#ifndef MIMIC_API
#  if defined(__GNUC__) && __GNUC__ >= 4
#    define MIMIC_API MIMIC_CALLCONV __attribute__ ((visibility("default")))
#  else
#    define MIMIC_API MIMIC_CALLCONV
#  endif
#endif // MIMIC_API

/**
 * We need `size_t' for the following definitions.
 */
#ifndef __size_t
typedef __SIZE_TYPE__ __size_t;
# if defined __USE_XOPEN || defined __USE_XOPEN2K8
typedef __SIZE_TYPE__ size_t;
# endif
#else
/** GNU CC stddef.h version defines __size_t as empty. We need a real definition. */
# undef __size_t
# define __size_t size_t
#endif  // __size_t

/**
 * Set up compiler-specific options for inline functions
 */
#ifndef MIMIC_INLINE_OKAY
#  ifdef __GNUC__
#    define MIMIC_INLINE_OKAY
#  endif
#endif // MIMIC_INLINE_OKAY

/**
 * If inline isn't supported, remove "__inline__", turning static
 * inline functions into static functions (resulting in code bloat
 * in all files which include the offending header files)
 */
#ifndef MIMIC_INLINE_OKAY
#define __inline__
#endif // MIMIC_INLINE_OKAY

#if defined(__STDC_VERSION__) && __STDC_VERSION__>=199901L
#define INLINE inline
#elif defined(__GNUC__)
#define INLINE __inline__
#else
#define INLINE
#endif

#ifndef MIMIC_NORETURN
#  if defined(__GNUC__)
#    define MIMIC_NORETURN __attribute__((noreturn))
#  else
#    define MIMIC_NORETURN
#  endif
#endif //MIMIC_NORETURN
