/*******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2005-2021, The Raetro authors and contributors
 *******************************************************************************
 *
 * PiSPi
 * Copyright (c) 2005-2021, The Raetro Authors (see AUTHORS file)
 *
 * PiSPi is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the
 * Free Software Foundation, version 3 or (at your option) any later version.
 *
 * PiSPi is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with PiSPi. If not, see <https://www.gnu.org/licenses>.
 *
 ******************************************************************************/

/*!*****************************************************************************
 * @file rpi_io.h
 * @brief
 ******************************************************************************/

#ifndef MIMIC_RPI_IO_H
#define MIMIC_RPI_IO_H

#include "stdinc.h"
#include "begin_code.h"
// Set up for C function definitions, even when using C++.
#ifdef __cplusplus
extern "C" {
#endif

extern MIMIC_API Uint8 pud_type_rpi4;
extern MIMIC_API Uint8 pud_compat_setting;

extern MIMIC_API void set_disk_led();
extern MIMIC_API void toggle_disk_led(bool on);
extern MIMIC_API void delay(unsigned int millis);
extern MIMIC_API void delayMicroseconds(Uint64 micros);
//////////////////////////////////////////////////////////////////////
extern MIMIC_API int rpi_io_init();
extern MIMIC_API void rpi_io_close();
//////////////////////////////////////////////////////////////////////
extern MIMIC_API Uint64 rpi_st_read();
extern MIMIC_API void rpi_st_delay(Uint64 offset_micros, Uint64 micros);
//////////////////////////////////////////////////////////////////////
extern MIMIC_API Uint32 rpi_io_read(const volatile Uint32 *paddr);
extern MIMIC_API Uint32 rpi_io_read_nb(const volatile Uint32 *paddr);
extern MIMIC_API void rpi_io_write(volatile Uint32 *paddr, Uint32 value);
extern MIMIC_API void rpi_io_write_nb(volatile Uint32 *paddr, Uint32 value);
extern MIMIC_API void rpi_io_set_bits(volatile Uint32 *paddr, Uint32 value, Uint32 mask);
extern MIMIC_API void rpi_io_fsel(Uint8 pin, Uint8 mode);
extern MIMIC_API void rpi_io_set(Uint8 pin);
extern MIMIC_API void rpi_io_clear(Uint8 pin);
extern MIMIC_API void rpi_io_pud(Uint8 pud);
extern MIMIC_API void rpi_io_pudclk(Uint8 pin, Uint8 on);
extern MIMIC_API void rpi_io_toggle(Uint8 pin, Uint8 on);
extern MIMIC_API void rpi_io_set_pud(Uint8 pin, Uint8 pud);
extern MIMIC_API Uint8 rpi_io_read_lev(Uint8 pin);
extern MIMIC_API Uint8 rpi_io_get_pud(Uint8 pin);

//////////////////////////////////////////////////////////////////////

extern MIMIC_API void rpi_io_spi_reset();
extern MIMIC_API int rpi_io_spi_init();
extern MIMIC_API void rpi_spi_set_default();

extern MIMIC_API Uint8 rpi_io_correct_order(Uint8 b);
extern MIMIC_API void rpi_io_spi_set_bit_order(Uint8 order);
extern MIMIC_API void rpi_spi_set_clock_divider(Uint16 divider);
extern MIMIC_API void rpi_io_spi_set_speed_hz(Uint32 speed_hz);
extern MIMIC_API void rpi_io_spi_set_data_mode(Uint8 mode);
extern MIMIC_API Uint8 rpi_io_spi_transfer(Uint8 value);
extern MIMIC_API void rpi_io_spi_transfernb(char *tx_buf, char *rx_buf, Uint32 len);
extern MIMIC_API void rpi_io_spi_writenb(const char *tbuf, Uint32 len);
extern MIMIC_API void rpi_io_spi_transfern(char *buf, Uint32 len);
extern MIMIC_API void rpi_io_spi_chip_select(Uint8 cs);
extern MIMIC_API void rpi_io_spi_set_cs_polarity(Uint8 cs, Uint8 active);
extern MIMIC_API void rpi_io_spi_write(Uint16 data);

#ifdef __cplusplus
}
#endif

#include "close_code.h"

#endif //MIMIC_RPI_IO_H
