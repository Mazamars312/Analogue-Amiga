/*******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * rbfloader
 * Copyright (c) 2020-2021, The Raetro Authors (see AUTHORS file)
 *
 * rbfloader is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the
 * Free Software Foundation, version 3 or (at your option) any later version.
 *
 * rbfloader is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with rbfloader. If not, see <https://www.gnu.org/licenses>.
 *
 ******************************************************************************/

/*!*****************************************************************************
 * @file jtag.h
 * @brief
 * @copyright (c) 2021 - Marcus Andrade <marcus@raetro.org>
 ******************************************************************************/

#ifndef PISPI_JTAG_H
#define PISPI_JTAG_H

// Set up for C function definitions, even when using C++.
#ifdef __cplusplus
extern "C" {
#endif

/**
 * @name JTAG Pins for bit bang mode
 */
/**@{*/
#define JTAG_PIN_TCK 17  /**< Test Clock */
#define JTAG_PIN_TDO 27  /**< Test Data Out */
#define JTAG_PIN_TDI 22  /**< Test Data In */
#define JTAG_PIN_TMS 4   /**< Test Mode Select */
/**@}*/

#define MAX_IR_CHAIN_LENGTH 100

class JTAG {
private:
	static std::string bytes_to_human(Uint64 bytes);
	static const char *bytes_to_human_string(Uint64 bytes);
	static void clock();
	static void reset();
	static void enter_select_dr();
	static void enter_shift_ir();
	static void enter_shift_dr();
	static void exit_shift();
	static void read_data(int bit_length);
	static void read_dr(int bit_length);
	static int determine_chain_length();
	static void pre_program();
	static void post_program();
	static void setup();
	static void release();
	static int scan();
	static int program_fpga(const char *rbf_filename);
public:
	static int load_rbf(const char *rbf_filename);
};

// Ends C function definitions when using C++.
#ifdef __cplusplus
}
#endif

#endif //PISPI_JTAG_H
