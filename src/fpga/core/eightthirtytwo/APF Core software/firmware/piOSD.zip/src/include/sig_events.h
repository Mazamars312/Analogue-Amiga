/*******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2005-2021, The Raetro authors and contributors
 *******************************************************************************
 *
 * MiMiC: Nostalgia Synthesizer Firmware
 * Copyright (c) 2005-2021, The Raetro Authors and contributors (see AUTHORS file)
 *
 * MiMiC NSX is a free software you can redistribute in source and synthesized
 * forms and/or modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation, version 3 or (at your option)
 * any later version.
 *
 * MiMiC NSX is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with the source code. If not, see <https://www.gnu.org/licenses>.
 *
 ******************************************************************************/

/*!*****************************************************************************
 * @file sig_events.h
 * @brief Interface of a generic handler for POSIX signals.
 ******************************************************************************/

#ifndef MIMIC_SIG_EVENTS_H
#define MIMIC_SIG_EVENTS_H

#include "stdinc.h"
#include "begin_code.h"
// Set up for C function definitions, even when using C++.
#ifdef __cplusplus
extern "C" {
#endif

#define LANG_SIGNAL_SIGHUP      "SIGHUP: Hangup detected on controlling terminal or death of controlling process"
#define LANG_SIGNAL_SIGINT      "SIGINT: Interrupt from keyboard"
#define LANG_SIGNAL_SIGQUIT     "SIGQUIT: Quit from keyboard"
#define LANG_SIGNAL_SIGILL      "SIGILL: Illegal Instruction"
#define LANG_SIGNAL_SIGTRAP     "SIGTRAP: Trace/breakpoint trap"
#define LANG_SIGNAL_SIGABRT     "SIGABRT/SIGIOT: Abort signal from abort(3)"
#define LANG_SIGNAL_SIGBUS      "SIGBUS: Bus error (bad memory access)"
#define LANG_SIGNAL_SIGFPE      "SIGFPE: Floating point exception"
#define LANG_SIGNAL_SIGKILL     "SIGKILL: Kill signal"
#define LANG_SIGNAL_SIGUSR1     "SIGUSR1: User-defined signal 1"
#define LANG_SIGNAL_SIGSEGV     "SIGSEGV: Invalid memory reference"
#define LANG_SIGNAL_SIGUSR2     "SIGUSR2: Bad argument to routine"
#define LANG_SIGNAL_SIGPIPE     "SIGPIPE: Broken pipe: write to pipe with no readers"
#define LANG_SIGNAL_SIGALRM     "SIGALRM: Timer signal from alarm(2)"
#define LANG_SIGNAL_SIGTERM     "SIGTERM: Termination signal"
#define LANG_SIGNAL_SIGSTKFLT   "SIGSTKFLT: Stack fault on coprocessor (unused)"
#define LANG_SIGNAL_SIGCHLD     "SIGCHLD: Child process has exit, interrupted, or resumed after being interrupted."
#define LANG_SIGNAL_SIGUNKNOWN  "SIGUNKNOWN: A truly new Signal finally comes to the app"
#define LANG_SIGNAL_GOODBYE     "Exiting now. Bye bye..."

extern MIMIC_API void critical_error_handler();
extern MIMIC_API void init_sigterm();
extern MIMIC_API void handle_sigterm(int sig_num);

#ifdef __cplusplus
}
#endif

#include "close_code.h"

#endif //MIMIC_SIG_EVENTS_H
