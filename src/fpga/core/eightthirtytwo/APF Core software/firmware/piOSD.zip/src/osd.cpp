/*******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2005-2021, The Raetro authors and contributors
 *******************************************************************************
 *
 * PiSPi
 * Copyright (c) 2005-2021, The Raetro Authors (see AUTHORS file)
 *
 * PiSPi is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the
 * Free Software Foundation, version 3 or (at your option) any later version.
 *
 * PiSPi is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with PiSPi. If not, see <https://www.gnu.org/licenses>.
 *
 ******************************************************************************/

/*!*****************************************************************************
 * @file osd.cpp
 * @brief
 ******************************************************************************/

#include "char_rom.h"
#include "mimic.h"

static int arrow;

static Uint8 title_buffer[64];

/**
 * @brief Rotate character for the OSD
 * @param in
 * @param out
 */
static void osd_rotate_char(const Uint8 *in, Uint8 *out) {
	int a, b, c;
	for(b = 0; b < 8; ++b) {
		a = 0;
		for(c = 0; c < 8; ++c) {
			a <<= 1;
			a |= (in[c] >> b) & 1;
		}
		out[b] = a;
	}
}

/**
 * @brief Compose the title, condensing character gaps.
 * @param title Title string
 * @param a Arrow > 0 = Display Right Arrow in Bottom Right, < 0 = Display Left
 * Arrow
 */
void osd_set_title(const char *title, int a) {
	// Compose the title, condensing character gaps
	arrow = a;
	int zeros = 0;
	int i = 0, j = 0;
	int outp = 0;
	//	const char *tmp_title = to_uppercase(title);
	const char *tmp_title = title;
	while(true) {
		int c = (Uint8) tmp_title[i++];
		if(c && (outp < OSD_HEIGHT - 8)) {
			Uint8 *p = &char_font[c][0];
			for(j = 0; j < 8; ++j) {
				Uint8 nc = *p++;
				if(nc) {
					zeros = 0;
					title_buffer[outp++] = nc;
				} else if(zeros == 0 || (c == ' ' && zeros < 5)) {
					title_buffer[outp++] = 0;
					zeros++;
				}
				if(outp > sizeof(title_buffer)) {
					break;
				}
			}
		} else {
			break;
		}
	}
	for(i = outp; i < OSD_HEIGHT; i++) {
		title_buffer[i] = 0;
	}

	// Center OSD
	int c = (OSD_HEIGHT - 1 - outp) / 2;
	memmove(title_buffer + c, title_buffer, outp);

	for(i = 0; i < c; ++i) {
		title_buffer[i] = 0;
	}

	// Rotate OSD
	for(i = 0; i < OSD_HEIGHT; i += 8) {
		Uint8 tmp[8];
		osd_rotate_char(&title_buffer[i], tmp);
		for(c = 0; c < 8; ++c) {
			title_buffer[i + c] = tmp[c];
		}
	}
}

/**
 * @brief Write a null terminated string `<S>` to the OSD buffer starting at
 * line `<N>`.
 * @param n
 * @param s
 * @param invert
 * @param stipple
 */
void osd_write(Uint8 n, const char *s, Uint8 invert, Uint8 stipple) {
	osd_write_offset(n, s, invert, stipple, 0);
}

/**
 * @brief Write a null terminated string `<S>` to the OSD buffer starting at
 * line `<N>`.
 * @param n Line Number
 * @param string Null terminated string
 * @param inver
 * @param stipple
 * @param offset
 */
void osd_write_offset(Uint8 n, const char *string, Uint8 inver, Uint8 stipple, char offset) {
	unsigned short i;
	Uint8 b;
	const Uint8 *p;
	Uint8 stipple_mask = 0xff;
	int line_limit = OSD_LINE_LEN;
	int arrow_mask = arrow;
	if(n == 7 && (arrow & OSD_ARROW_RIGHT)) {
		line_limit -= 22;
	}

	if(stipple) {
		stipple_mask = 0x55;
		stipple = 0xff;
	} else {
		stipple = 0;
	}

	// Select buffer and line to write to
	spi_osd_cmd_cont(OSD_CMD_WRITE | n);

	if(inver) {
		inver = 255;
	}

	i = 0;
	// Send all characters in string to OSD
	while(true) {
		if(i == 0) {
			// Render side stripe
			Uint8 j;
			p = &title_buffer[(7 - n) * 8];
			spi16(0xffff); // Left white border
			for(j = 0; j < 8; j++) {
				spi_n(255 ^ *p++, 2);
			}
			spi16(0xffff); // Right white border
			spi16(0x0000); // Blue gap
			i += 22;
		} else if(n == 7 && (arrow_mask & OSD_ARROW_LEFT)) { // Draw initial arrow
			spi24(0x00);
			p = &char_font[0x10][0];
			for(b = 0; b < 8; b++) {
				spi8(*p++ << offset);
			}
			p = &char_font[0x14][0];
			for(b = 0; b < 8; b++) {
				spi8(*p++ << offset);
			}
			spi24(0x00);
			spi_n(inver, 2);
			i += 24;
			arrow_mask &= ~OSD_ARROW_LEFT;
			if(*string++ == 0) {
				break;
			} // Skip 3 characters, to keep alignment the same.
			if(*string++ == 0) {
				break;
			}
			if(*string++ == 0) {
				break;
			}
		} else {
			b = *string++;
			if(b == 0) {
				// End of string
				break;
			} else if(b == 0x0d || b == 0x0a) {
				// Carriage return / linefeed, go to next line increment line counter
				if(++n >= line_limit) {
					n = 0;
				}
				// Send new line number to OSD
				spi_disable_osd();
				spi_osd_cmd_cont(OSD_CMD_WRITE | n);
			} else if(i < (line_limit - 8)) { // normal character
				Uint8 c;
				p = &char_font[b][0];
				for(c = 0; c < 8; c++) {
					spi8(((*p++ << offset) & stipple_mask) ^ inver);
					stipple_mask ^= stipple;
				}
				i += 8;
			}
		}
	}

	for(; (int) i < line_limit; i++) {
		// clear end of line
		spi8(inver);
	}

	if(n == 7 && (arrow_mask & OSD_ARROW_RIGHT)) {
		// Draw final arrow if needed
		Uint8 c;
		spi24(0x00);
		p = &char_font[0x15][0];
		for(c = 0; c < 8; c++) {
			spi8(*p++ << offset);
		}
		p = &char_font[0x11][0];
		for(c = 0; c < 8; c++) {
			spi8(*p++ << offset);
		}
		spi24(0x00);
		i += 22;
	}
	// deselect OSD SPI device
	spi_disable_osd();
}

/**
 * @brief clear OSD frame buffer
 */
void osd_clear() {
	// select buffer to write to
	spi_osd_cmd_cont(OSD_CMD_WRITE | 0x18);
	// clear buffer
	spi_n(0x00, OSD_LINE_LEN * OSD_TOTAL_LINES);
	// deselect OSD SPI device
	spi_disable_osd();
}

/**
 * @brief Enable displaying of OSD
 */
void osd_enable() { spi_osd_cmd(OSD_CMD_ENABLE); }

/**
 * @brief Disable displaying of OSD
 */
void osd_disable() { spi_osd_cmd(OSD_CMD_DISABLE); }
