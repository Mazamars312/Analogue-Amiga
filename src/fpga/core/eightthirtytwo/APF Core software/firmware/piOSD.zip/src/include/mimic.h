/*******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2005-2021, The Raetro authors and contributors
 *******************************************************************************
 *
 * PiSPi
 * Copyright (c) 2005-2021, The Raetro Authors (see AUTHORS file)
 *
 * PiSPi is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the
 * Free Software Foundation, version 3 or (at your option) any later version.
 *
 * PiSPi is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with PiSPi. If not, see <https://www.gnu.org/licenses>.
 *
 ******************************************************************************/

/*!*****************************************************************************
 * @file mimic.h
 * @brief Interface of main application for initializations and definitions.
 ******************************************************************************/

#ifndef PISPI_MIMIC_H
#define PISPI_MIMIC_H

#include "stdinc.h"

#include "debug.h"
#include "osd.h"
#include "rpi_io.h"
#include "rpi_spi.h"
#include "sig_events.h"

#include "begin_code.h"
// Set up for C function definitions, even when using C++.
#ifdef __cplusplus
extern "C" {
#endif

extern Uint32 app_initialized;

/**
 * @name SPI Pins
 */
/**@{*/
#define SPI_PIN_CE1  7
#define SPI_PIN_CE0  8
#define SPI_PIN_MISO 9
#define SPI_PIN_MOSI 10
#define SPI_PIN_SCLK 11
/**@}*/


#define HIGH                          0x1          /*!< This means pin HIGH, true, 3.3v on a pin. */
#define LOW                           0x0          /*!< This means pin LOW, false,   0v on a pin. */

#define RPI_CORE_CLK_HZ               250000000    /*!< 250 MHz */

#ifdef RPI_2711
#define RPI_REG_BASE                  0xFE000000  /*!< RPi 4 */
#define RPI_REG_SIZE                  0x01800000  /*!< RPi 4 */
#else
#ifdef RPI_2835
#define RPI_REG_BASE                  0x20000000  /*!< RPi (1/Zero) */
#else
#define RPI_REG_BASE                  0x3F000000  /*!< RPi (2/3) */
#endif
#define RPI_REG_SIZE                  0x01000000  /*!< RPi (1/2/3) */
#endif

#define RPI_ST_BASE                   0x3000   /** System Timer */
#define RPI_GPIO_PADS                 0x100000 /** Pads  */
#define RPI_CLOCK_BASE                0x101000 /** Clock */
#define RPI_GPIO_BASE                 0x200000 /** GPIO  */
#define RPI_SPI0_BASE                 0x204000 /** SPI0  */
#define RPI_BSC0_BASE                 0x205000 /** BSC0  */
#define RPI_GPIO_PWM                  0x20C000 /** PWM   */
#define RPI_AUX_BASE                  0x215000 /** AUX   */
#define RPI_SPI1_BASE                 0x215080 /** SPI1  */
#define RPI_SPI2_BASE                 0x2150C0 /** SPI2  */
#define RPI_BSC1_BASE                 0x804000 /** BSC1  */

/**
 * @brief GPIO register offsets.
 * Offsets into the GPIO Peripheral block in bytes per 6.1 Register View
 * The BCM2835 has 54 GPIO pins.
 * BCM2835 data sheet, Page 90 onwards.
 */
#define RPI_GPFSEL0                   0x0000   /*!< GPIO Function Select 0 */
#define RPI_GPFSEL1                   0x0004   /*!< GPIO Function Select 1 */
#define RPI_GPFSEL2                   0x0008   /*!< GPIO Function Select 2 */
#define RPI_GPFSEL3                   0x000c   /*!< GPIO Function Select 3 */
#define RPI_GPFSEL4                   0x0010   /*!< GPIO Function Select 4 */
#define RPI_GPFSEL5                   0x0014   /*!< GPIO Function Select 5 */
#define RPI_GPSET0                    0x001c   /*!< GPIO Pin Output Set 0 */
#define RPI_GPSET1                    0x0020   /*!< GPIO Pin Output Set 1 */
#define RPI_GPCLR0                    0x0028   /*!< GPIO Pin Output Clear 0 */
#define RPI_GPCLR1                    0x002c   /*!< GPIO Pin Output Clear 1 */
#define RPI_GPLEV0                    0x0034   /*!< GPIO Pin Level 0 */
#define RPI_GPLEV1                    0x0038   /*!< GPIO Pin Level 1 */
#define RPI_GPEDS0                    0x0040   /*!< GPIO Pin Event Detect Status 0 */
#define RPI_GPEDS1                    0x0044   /*!< GPIO Pin Event Detect Status 1 */
#define RPI_GPREN0                    0x004c   /*!< GPIO Pin Rising Edge Detect Enable 0 */
#define RPI_GPREN1                    0x0050   /*!< GPIO Pin Rising Edge Detect Enable 1 */
#define RPI_GPFEN0                    0x0058   /*!< GPIO Pin Falling Edge Detect Enable 0 */
#define RPI_GPFEN1                    0x005c   /*!< GPIO Pin Falling Edge Detect Enable 1 */
#define RPI_GPHEN0                    0x0064   /*!< GPIO Pin High Detect Enable 0 */
#define RPI_GPHEN1                    0x0068   /*!< GPIO Pin High Detect Enable 1 */
#define RPI_GPLEN0                    0x0070   /*!< GPIO Pin Low Detect Enable 0 */
#define RPI_GPLEN1                    0x0074   /*!< GPIO Pin Low Detect Enable 1 */
#define RPI_GPAREN0                   0x007c   /*!< GPIO Pin Async. Rising Edge Detect 0 */
#define RPI_GPAREN1                   0x0080   /*!< GPIO Pin Async. Rising Edge Detect 1 */
#define RPI_GPAFEN0                   0x0088   /*!< GPIO Pin Async. Falling Edge Detect 0 */
#define RPI_GPAFEN1                   0x008c   /*!< GPIO Pin Async. Falling Edge Detect 1 */
#define RPI_GPPUD                     0x0094   /*!< GPIO Pin Pull-up/down Enable */
#define RPI_GPPUDCLK0                 0x0098   /*!< GPIO Pin Pull-up/down Enable Clock 0 */
#define RPI_GPPUDCLK1                 0x009c   /*!< GPIO Pin Pull-up/down Enable Clock 1 */

/* 2711 has a different method for pin pull-up/down/enable  */
#define RPI_GPPUPPDN0                 0x00e4   /*!< Pin pull-up/down for pins 15:0  */
#define RPI_GPPUPPDN1                 0x00e8   /*!< Pin pull-up/down for pins 31:16 */
#define RPI_GPPUPPDN2                 0x00ec   /*!< Pin pull-up/down for pins 47:32 */
#define RPI_GPPUPPDN3                 0x00f0   /*!< Pin pull-up/down for pins 57:48 */

/**
 * Defines for SPI
 * GPIO register offsets from RPI_SPI0_BASE.
 * Offsets into the SPI Peripheral block in bytes per 10.5 SPI Register Map
 */
#define RPI_SPI0_CS                   0x0000     /*!< SPI Master Control and Status */
#define RPI_SPI0_FIFO                 0x0004     /*!< SPI Master TX and RX FIFOs */
#define RPI_SPI0_CLK                  0x0008     /*!< SPI Master Clock Divider */
#define RPI_SPI0_DLEN                 0x000c     /*!< SPI Master Data Length */
#define RPI_SPI0_LTOH                 0x0010     /*!< SPI LOSSI mode TOH */
#define RPI_SPI0_DC                   0x0014     /*!< SPI DMA DREQ Controls */

/* Register masks for SPI0_CS */
#define RPI_SPI0_CS_LEN_LONG          0x02000000 /*!< Enable Long data word in Lossi mode if DMA_LEN is set */
#define RPI_SPI0_CS_DMA_LEN           0x01000000 /*!< Enable DMA mode in Lossi mode */
#define RPI_SPI0_CS_CSPOL2            0x00800000 /*!< Chip Select 2 Polarity */
#define RPI_SPI0_CS_CSPOL1            0x00400000 /*!< Chip Select 1 Polarity */
#define RPI_SPI0_CS_CSPOL0            0x00200000 /*!< Chip Select 0 Polarity */
#define RPI_SPI0_CS_RXF               0x00100000 /*!< RXF - RX FIFO Full */
#define RPI_SPI0_CS_RXR               0x00080000 /*!< RXR RX FIFO needs Reading (full) */
#define RPI_SPI0_CS_TXD               0x00040000 /*!< TXD TX FIFO can accept Data */
#define RPI_SPI0_CS_RXD               0x00020000 /*!< RXD RX FIFO contains Data */
#define RPI_SPI0_CS_DONE              0x00010000 /*!< Done transfer Done */
#define RPI_SPI0_CS_TE_EN             0x00008000 /*!< Unused */
#define RPI_SPI0_CS_LMONO             0x00004000 /*!< Unused */
#define RPI_SPI0_CS_LEN               0x00002000 /*!< LEN LoSSI enable */
#define RPI_SPI0_CS_REN               0x00001000 /*!< REN Read Enable */
#define RPI_SPI0_CS_ADCS              0x00000800 /*!< ADCS Automatically Deassert Chip Select */
#define RPI_SPI0_CS_INTR              0x00000400 /*!< INTR Interrupt on RXR */
#define RPI_SPI0_CS_INTD              0x00000200 /*!< INTD Interrupt on Done */
#define RPI_SPI0_CS_DMAEN             0x00000100 /*!< DMAEN DMA Enable */
#define RPI_SPI0_CS_TA                0x00000080 /*!< Transfer Active */
#define RPI_SPI0_CS_CSPOL             0x00000040 /*!< Chip Select Polarity */
#define RPI_SPI0_CS_CLEAR             0x00000030 /*!< Clear FIFO Clear RX and TX */
#define RPI_SPI0_CS_CLEAR_RX          0x00000020 /*!< Clear FIFO Clear RX  */
#define RPI_SPI0_CS_CLEAR_TX          0x00000010 /*!< Clear FIFO Clear TX  */
#define RPI_SPI0_CS_CPOL              0x00000008 /*!< Clock Polarity */
#define RPI_SPI0_CS_CPHA              0x00000004 /*!< Clock Phase */
#define RPI_SPI0_CS_CS                0x00000003 /*!< Chip Select */

///////////////////////////////////////////////

/**
 * @brief Defines for ST
 *
 * GPIO register offsets from RPI_ST_BASE.
 * Offsets into the ST Peripheral block in bytes per 12.1 System Timer Registers
 * The System Timer peripheral provides four 32-bit timer channels and a single 64-bit free running counter.
 * RPI_ST_CLO is the System Timer Counter Lower bits register.
 * The system timer free-running counter lower register is a read-only register that returns the current value
 * of the lower 32-bits of the free running counter.
 * RPI_ST_CHI is the System Timer Counter Upper bits register.
 * The system timer free-running counter upper register is a read-only register that returns the current value
 * of the upper 32-bits of the free running counter.
 */
#define RPI_ST_CS                     0x0000 /*!< System Timer Control/Status */
#define RPI_ST_CLO                    0x0004 /*!< System Timer Counter Lower 32 bits */
#define RPI_ST_CHI                    0x0008 /*!< System Timer Counter Upper 32 bits */

///////////////////////////////////////////////

#define DISK_LED_ON                   toggle_disk_led(true)
#define DISK_LED_OFF                  toggle_disk_led(false)

/**
 * @brief Port function select modes for rpi_io_fsel()
 */
typedef enum {
	RPI_FSEL_INPT = 0x00, /*!< Input  0b000 */
	RPI_FSEL_OUTP = 0x01, /*!< Output 0b001 */
	RPI_FSEL_ALT0 = 0x04, /*!< ALT0   0b100 */
	RPI_FSEL_ALT1 = 0x05, /*!< ALT1   0b101 */
	RPI_FSEL_ALT2 = 0x06, /*!< ALT2   0b110 */
	RPI_FSEL_ALT3 = 0x07, /*!< ALT3   0b111 */
	RPI_FSEL_ALT4 = 0x03, /*!< ALT4   0b011 */
	RPI_FSEL_ALT5 = 0x02, /*!< ALT5   0b010 */
	RPI_FSEL_MASK = 0x07  /*!< MASK   0b111 */
} RPI_FSEL_ENUM;

/**
 * @brief Pullup/Pulldown defines for rpi_io_pud()
 */
typedef enum {
	RPI_PUD_OFF   = 0x00, /*!< Off ? disable pull-up/down 0b00 */
	RPI_PUD_DOWN  = 0x01, /*!< Enable Pull Down control 0b01 */
	RPI_PUD_UP    = 0x02, /*!< Enable Pull Up control 0b10  */
	RPI_PUD_ERROR = 0x08  /*!< Need a value for pud functions that can't work unless RPI 4 */
} RPI_PUD_CRTL;

/**
 * @brief SPI Bit order
 * Specifies the SPI data bit ordering for rpi_io_set_bit_order()
 */
typedef enum {
	RPI_SPI_LSBFIRST = 0,     /*!< LSB First */
	RPI_SPI_MSBFIRST = 1      /*!< MSB First */
} SPI_BIT_ORDER;

/**
 * @brief SPI Data mode
 * Specify the SPI data mode to be passed to rpi_io_set_data_mode()
 */
typedef enum {
	RPI_SPI_MODE0 = 0,    /*!< CPOL = 0, CPHA = 0 */
	RPI_SPI_MODE1 = 1,    /*!< CPOL = 0, CPHA = 1 */
	RPI_SPI_MODE2 = 2,    /*!< CPOL = 1, CPHA = 0 */
	RPI_SPI_MODE3 = 3     /*!< CPOL = 1, CPHA = 1 */
} SPI_DATA_MODE;

/**
 * @brief Specify the SPI chip select pin(s)
 */
typedef enum {
	RPI_SPI_CS0 = 0,      /*!< CS 0 */
	RPI_SPI_CS1 = 1,      /*!< CS 1 */
	RPI_SPI_CS2 = 2,      /*!< CS 2 (ie pins CS1 and CS2 are asserted) */
	RPI_SPI_CS_NONE = 3   /*!< No CS, Manual control */
} SPI_CHIP_SELECT;

/**
 * @brief SPI Clock Divider
 * Specifies the divider used to generate the SPI clock from the system clock.
 * Figures below give the divider, clock period and clock frequency.
 *
 * Clock divided is based on nominal core clock rate of 400MHz on RPi3 and 250MHz on RPi1 and RPi2.
 * The system clock frequency on RPi3 is different, so the frequency you get from a given divider will be different.
 * It is possible to change the core clock rate of the RPi 3 back to 250MHz, by putting core_freq=250 in the config.txt
 *
 * @note Don't expect speeds grater then 50Mhz to be reliable.
 */
typedef enum {
	RPI_SPI_CLOCK_DIVIDER_65536 = 0,     /*!<  65536 = 6.1035156kHz   | 3.814697260kHz */
	RPI_SPI_CLOCK_DIVIDER_32768 = 32768, /*!<  32768 = 12.20703125kHz | 7.629394531kHz */
	RPI_SPI_CLOCK_DIVIDER_16384 = 16384, /*!<  16384 = 24.4140625kHz  | 15.25878906kHz */
	RPI_SPI_CLOCK_DIVIDER_8192  = 8192,  /*!<  8192  = 48.828125kHz   | 30.51757813kHz */
	RPI_SPI_CLOCK_DIVIDER_4096  = 4096,  /*!<  4096  = 97.65625kHz    | 61.03515625kHz */
	RPI_SPI_CLOCK_DIVIDER_2048  = 2048,  /*!<  2048  = 195.3125kHz    | 122.0703125kHz */
	RPI_SPI_CLOCK_DIVIDER_1024  = 1024,  /*!<  1024  = 390.625kHz     | 244.140625kHz  */
	RPI_SPI_CLOCK_DIVIDER_512   = 512,   /*!<  512   = 781.25kHz      | 488.28125kHz   */
	RPI_SPI_CLOCK_DIVIDER_256   = 256,   /*!<  256   = 1.5625MHz      | 976.5625kHz    */
	RPI_SPI_CLOCK_DIVIDER_128   = 128,   /*!<  128   = 3.125MHz       | 1.953125MHz    */
	RPI_SPI_CLOCK_DIVIDER_64    = 64,    /*!<  64    = 6.250MHz       | 3.90625MHz     */
	RPI_SPI_CLOCK_DIVIDER_32    = 32,    /*!<  32    = 12.5MHz        | 7.8125MHz      */
	RPI_SPI_CLOCK_DIVIDER_16    = 16,    /*!<  16    = 25MHz          | 15.625MHz      */
	RPI_SPI_CLOCK_DIVIDER_8     = 8,     /*!<  8     = 50MHz          | 31.25MHz       */
	RPI_SPI_CLOCK_DIVIDER_4     = 4,     /*!<  4     = 100MHz         | 62.5MHz        */
	RPI_SPI_CLOCK_DIVIDER_2     = 2,     /*!<  2     = 200MHz         | 125MHz         */
	RPI_SPI_CLOCK_DIVIDER_1     = 1      /*!<  1     = 6.1035156kHz.  | 3.814697260kHz | Same as 0/65536 */
} SPI_CLOCK_DIVIDER;

#ifdef __cplusplus
}
#endif

#include "close_code.h"

#endif //PISPI_MIMIC_H
