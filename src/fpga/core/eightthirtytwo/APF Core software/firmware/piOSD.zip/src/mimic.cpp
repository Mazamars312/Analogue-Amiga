/*******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2005-2021, The Raetro authors and contributors
 *******************************************************************************
 *
 * PiSPi
 * Copyright (c) 2005-2021, The Raetro Authors (see AUTHORS file)
 *
 * PiSPi is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the
 * Free Software Foundation, version 3 or (at your option) any later version.
 *
 * PiSPi is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with PiSPi. If not, see <https://www.gnu.org/licenses>.
 *
 ******************************************************************************/

/*!*****************************************************************************
 * @file mimic.cpp
 * @brief
 ******************************************************************************/

#include "mimic.h"
#include "jtag.h"

Uint32 app_initialized = 0;

int main() {
	init_sigterm();
	rpi_io_init();
	set_disk_led();
	rpi_io_spi_init();
	rpi_spi_set_default();

	while(app_initialized) {
		osd_clear();
		osd_enable();
		osd_write(0, " Hi!", 0, 0);
		sleep(5);
		osd_disable();
		sleep(1);
	}

	rpi_io_spi_reset();
	rpi_io_close();
	return 0;
}
