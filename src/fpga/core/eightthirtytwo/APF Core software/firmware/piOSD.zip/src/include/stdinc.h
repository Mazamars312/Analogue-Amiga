/*******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2005-2021, The Raetro authors and contributors
 *******************************************************************************
 *
 * PiSPi
 * Copyright (c) 2005-2021, The Raetro Authors (see AUTHORS file)
 *
 * PiSPi is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the
 * Free Software Foundation, version 3 or (at your option) any later version.
 *
 * PiSPi is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with PiSPi. If not, see <https://www.gnu.org/licenses>.
 *
 ******************************************************************************/

/*!*****************************************************************************
 * @file stdinc.h
 * @brief Interface of standard C Library definitions.
 *
 * This is the preferred location of all CPP hackery to make $random_compiler
 * work like something approaching a C99 (or maybe more accurately GNU99)
 * compiler.
 *
 * It is assumed that this header will be included after "config.h".
 ******************************************************************************/

#ifndef MIMIC_STDINC_H
#define MIMIC_STDINC_H

// C Libraries
#include <alloca.h>
#include <cassert>
#include <cctype>
#include <cerrno>
#include <cinttypes>
#include <climits>
#include <clocale>
#include <cmath>
#include <csignal>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <dirent.h>
#include <fcntl.h>
#include <ifaddrs.h>
#include <linux/fb.h>
#include <linux/input.h>
#include <linux/magic.h>
#include <linux/spi/spidev.h>
#include <linux/types.h>
#include <linux/uinput.h>
#include <linux/vt.h>
#include <malloc.h>
#include <netdb.h>
#include <sched.h>
#include <sys/inotify.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/mount.h>
#include <sys/poll.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/vfs.h>
#include <sys/wait.h>
#include <unistd.h>
// C++ Libraries
#include <algorithm>
#include <cassert>
#include <deque>
#include <exception>
#include <fstream>
#include <ios>
#include <iostream>
#include <map>
#include <memory>
#include <sstream>
#include <string>
#include <typeinfo>
#include <unordered_map>
#include <utility>
#include <vector>

/**
 * Compilation flags used to enable/disable features
 */
#define ENABLED  1
#define DISABLED 0

/**
 * The number of elements in an array.
 */
#define MIMIC_ARRAY_SIZE(array)    (sizeof(array)/sizeof((array)[0]))
#define MIMIC_TABLE_SIZE(table)    MIMIC_ARRAY_SIZE(table)

/**
 * @brief Macro useful for building other macros with strings in them.
 *
 * e.g. #define LOG_ERROR(X) output_debug_string(MIMIC_STRINGIFY_ARG(__FUNCTION__) ": " X "\n")
 */
#define MIMIC_STRINGIFY_ARG(arg)  #arg

/**
 * @name Cast operators
 *
 * Use proper C++ casts when compiled as C++ to be compatible with the option
 * -Wold-style-cast of GCC (and -Werror=old-style-cast in GCC 4.2 and above).
 */
/**@{*/
#ifdef __cplusplus
#define MIMIC_reinterpret_cast(type, expression) reinterpret_cast<type>(expression)
#define MIMIC_static_cast(type, expression) static_cast<type>(expression)
#define MIMIC_const_cast(type, expression) const_cast<type>(expression)
#else
#define MIMIC_reinterpret_cast(type, expression) ((type)(expression))
#define MIMIC_static_cast(type, expression) ((type)(expression))
#define MIMIC_const_cast(type, expression) ((type)(expression))
#endif
/**@}*/

/**
 * @brief Basic data types
 */
/**@{*/

/**
 * @brief Boolean data type
 */
/**@{*/
#ifdef __CC_ARM
/** ARM's compiler throws warnings if we use an enum: like "MIMIC_bool x = a < b;" */
#define MIMIC_FALSE 0
#define MIMIC_TRUE 1
typedef int MIMIC_bool;
#else
typedef enum {
	MIMIC_FALSE = 0,
	MIMIC_TRUE = 1
} MIMIC_bool;
#endif

#ifndef TRUE
#define TRUE  1
#endif

#ifndef FALSE
#define FALSE 0
#endif
/**@}*/

/**
 * @brief Unicode Data Types
 */
/**@{*/
typedef u_char Uchar;       /**< Type for Unsigned Character representation, for every value in range [0, 255] */
typedef wchar_t Wchar;      /**< Type for wide character representation, required to be large enough to represent any supported character code point */

/**
 * @brief Type for UTF-16 character representation, required to be large enough to represent any UTF-16 code unit (16 bits)
 * @typedef The base type for UTF-16 code units and pointers.
 * C++11 defines char16_t as bit-compatible with uint16_t, but as a distinct type.
 * In C, char16_t is a simple typedef of uint_least16_t.
 * @since C++11
 */
typedef char16_t Uchar16;
/**
 * @brief Type for UTF-32 character representation, required to be large enough to represent any UTF-32 code unit (32 bits)
 * @typedef Define UChar32 as a type for single Unicode code points.
 * UChar32 is a signed 32-bit integer (same as int32_t).
 * The Unicode code point range is 0..0x10ffff.
 * All other values (negative or >=0x110000) are illegal as Unicode code points.
 * @since C++11
 */
typedef char32_t UChar32;
/**@}*/

// 28
// 0x1C   /* = Hexadecimal representation for decimal 28 */
// 034    /* = Octal representation for decimal 28 */
/**
 * Decimal Constants
 * int                 dec_int    = 28;
 * unsigned            dec_uint   = 4000000024u;
 * long                dec_long   = 2000000022l;
 * unsigned long       dec_ulong  = 4000000000ul;
 * long long           dec_llong  = 9000000000LL;
 * unsigned long long  dec_ullong = 900000000001ull;
 * __int64             dec_i64    = 9000000000002I64;
 * unsigned __int64    dec_ui64   = 90000000000004ui64;
 *
 * Octal Constants
 * int                 oct_int    = 024;
 * unsigned            oct_uint   = 04000000024u;
 * long                oct_long   = 02000000022l;
 * unsigned long       oct_ulong  = 04000000000UL;
 * long long           oct_llong  = 044000000000000ll;
 * unsigned long long  oct_ullong = 044400000000000001Ull;
 * __int64             oct_i64    = 04444000000000000002i64;
 * unsigned __int64    oct_ui64   = 04444000000000000004uI64;
 *
 * Hexadecimal Constants
 * int                 hex_int    = 0x2a;
 * unsigned            hex_uint   = 0XA0000024u;
 * long                hex_long   = 0x20000022l;
 * unsigned long       hex_ulong  = 0XA0000021uL;
 * long long           hex_llong  = 0x8a000000000000ll;
 * unsigned long long  hex_ullong = 0x8A40000000000010uLL;
 * __int64             hex_i64    = 0x4a44000000000020I64;
 * unsigned __int64    hex_ui64   = 0x8a44000000000040Ui64;
*/

/* Fast types.  */
/* Signed.  */
typedef int_fast8_t  SintF8;    /**< Fastest signed integer type with width of at least 8 bits  */
typedef int_fast16_t SintF16;   /**< Fastest signed integer type with width of at least 16 bits */
typedef int_fast32_t SintF32;   /**< Fastest signed integer type with width of at least 32 bits */
typedef int_fast64_t SintF64;   /**< Fastest signed integer type with width of at least 64 bits */
/* Unsigned.  */
typedef uint_fast8_t  UintF8;   /**< Fastest unsigned integer type with width of at least 8 bits  */
typedef uint_fast16_t UintF16;  /**< Fastest unsigned integer type with width of at least 16 bits */
typedef uint_fast32_t UintF32;  /**< Fastest unsigned integer type with width of at least 32 bits */
typedef uint_fast64_t UintF64;  /**< Fastest unsigned integer type with width of at least 64 bits */

/* Signed.  */
typedef int8_t Sint8;       /**< Signed 8-bit integer type. */
typedef int16_t Sint16;     /**< Signed 16-bit integer type. */
typedef int32_t Sint32;     /**< Signed 32-bit integer type. */
typedef intmax_t SintMAX;   /**< Maximum-width signed integer type. */
/* Unsigned.  */
typedef uintptr_t UintP;    /**< Unsigned integer type that is capable of storing a data pointer. */
typedef uint8_t Uint8;      /**< Unsigned 8-bit integer type. */
typedef uint16_t Uint16;    /**< Unsigned 16-bit integer type. */
typedef uint32_t Uint32;    /**< Unsigned 32-bit integer type. */

#ifndef MIMIC_NO_64BIT_TYPE
typedef int64_t Sint64;     /**< Signed 64-bit integer type. */
typedef uint64_t Uint64;    /**< Unsigned 64-bit integer type. */
#else
/** This is really just a hack to prevent the compiler from complaining */
typedef struct {
	Uint32 hi;
	Uint32 lo;
} Uint64, Sint64;
#endif
/**@}*/

/**
 * @brief Miscellaneous macros
 */
/**@{*/
#ifndef LSB
#define LSB(x) ((x) & 0xFF)
#endif

#ifndef MSB
#define MSB(x) (((x) >> 8) & 0xFF)
#endif

#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))
#endif

//Infinite delay
#define INFINITE_DELAY ((Uint32) -1)
//Maximum delay
#define MAX_DELAY (INFINITE_DELAY / 2)
/**@}*/

/**
 * @brief Annotations to help code analysis tools
 */
#ifdef MIMIC_DISABLE_ANALYZE_MACROS
#define MIMIC_IN_BYTECAP(x)
#define MIMIC_INOUT_Z_CAP(x)
#define MIMIC_OUT_Z_CAP(x)
#define MIMIC_OUT_CAP(x)
#define MIMIC_OUT_BYTECAP(x)
#define MIMIC_OUT_Z_BYTECAP(x)
#define MIMIC_PRINTF_FORMAT_STRING
#define MIMIC_SCANF_FORMAT_STRING
#define MIMIC_PRINTF_VARARG_FUNC( fmtargnumber )
#define MIMIC_SCANF_VARARG_FUNC( fmtargnumber )
#else
#define MIMIC_IN_BYTECAP(x)
#define MIMIC_INOUT_Z_CAP(x)
#define MIMIC_OUT_Z_CAP(x)
#define MIMIC_OUT_CAP(x)
#define MIMIC_OUT_BYTECAP(x)
#define MIMIC_OUT_Z_BYTECAP(x)
#define MIMIC_PRINTF_FORMAT_STRING
#define MIMIC_SCANF_FORMAT_STRING
#if defined(__GNUC__)
#define MIMIC_PRINTF_VARARG_FUNC(fmtargnumber) __attribute__ (( format( __printf__, fmtargnumber, (fmtargnumber)+1 )))
#define MIMIC_SCANF_VARARG_FUNC(fmtargnumber) __attribute__ (( format( __scanf__, fmtargnumber, (fmtargnumber)+1 )))
#else
#define MIMIC_PRINTF_VARARG_FUNC( fmtargnumber )
#define MIMIC_SCANF_VARARG_FUNC( fmtargnumber )
#endif
#endif // MIMIC_DISABLE_ANALYZE_MACROS

/** @name Make sure the types really have the right sizes */
/**@{*/
#define MIMIC_COMPILE_TIME_ASSERT(name, x) typedef int MIMIC_dummy_ ## name[(x) * 2 - 1]

MIMIC_COMPILE_TIME_ASSERT(uint8,  sizeof(Uint8)  == 1);
MIMIC_COMPILE_TIME_ASSERT(sint8,  sizeof(Sint8)  == 1);
MIMIC_COMPILE_TIME_ASSERT(uint16, sizeof(Uint16) == 2);
MIMIC_COMPILE_TIME_ASSERT(sint16, sizeof(Sint16) == 2);
MIMIC_COMPILE_TIME_ASSERT(uint32, sizeof(Uint32) == 4);
MIMIC_COMPILE_TIME_ASSERT(sint32, sizeof(Sint32) == 4);
MIMIC_COMPILE_TIME_ASSERT(uint64, sizeof(Uint64) == 8);
MIMIC_COMPILE_TIME_ASSERT(sint64, sizeof(Sint64) == 8);
/**@}*/

/** @name Enum Size Check
 *  Check to make sure enums are the size of ints, for structure packing.
 */
/**@{*/
typedef enum {
	DUMMY_ENUM_VALUE
} MIMIC_DUMMY_ENUM;

MIMIC_COMPILE_TIME_ASSERT(enum, sizeof(MIMIC_DUMMY_ENUM) == sizeof(int));
/**@}*/

#include "begin_code.h"
// Set up for C function definitions, even when using C++.
#ifdef __cplusplus
extern "C" {
#endif

#ifndef M_LN2
#define M_LN2 0.69314718055994530942
#endif

#ifndef M_PI
#define M_PI  3.14159265358979323846
#endif

#ifndef MIMIC_NO_HAVE_CTYPE_H
#define MIMIC_isdigit(X)    isdigit(X)
#define MIMIC_isspace(X)    isspace(X)
#define MIMIC_isupper(X)    isupper(X)
#define MIMIC_islower(X)    islower(X)
#define MIMIC_toupper(X)    toupper(X)
#define MIMIC_tolower(X)    tolower(X)
#else
#define MIMIC_isdigit(X)    (((X) >= '0') && ((X) <= '9'))
#define MIMIC_isspace(X)    (((X) == ' ') || ((X) == '\t') || ((X) == '\r') || ((X) == '\n'))
#define MIMIC_isupper(X)    ((x) >= 'A') && ((x) <= 'Z')
#define MIMIC_islower(X)    ((x) >= 'a') && ((x) <= 'z')
#define MIMIC_toupper(X)    (((X) >= 'a') && ((X) <= 'z') ? ('A'+((X)-'a')) : (X))
#define MIMIC_tolower(X)    (((X) >= 'A') && ((X) <= 'Z') ? ('a'+((X)-'A')) : (X))
#endif

#define MIMIC_isalphanum(X) (MIMIC_tolower(X) || MIMIC_toupper(X) || MIMIC_isdigit(X))
#define MIMIC_iscomment(X)  (((X) == ';'))
#define MIMIC_islineend(X)  (((X) == '\n'))
#define MIMIC_isquote(X)    (((X) == '"'))
#define MIMIC_isvalid(X)    (MIMIC_isalphanum(X) || MIMIC_isspecial(X))
#define MIMIC_isspecial(X)  (((X) == '[') || ((X) == ']') || ((X) == '(') || ((X) == ')') || \
                             ((X) == '-') || ((X) == '+') || ((X) == '/') || ((X) == '=') || \
                             ((X) == '#') || ((X) == '$') || ((X) == '@') || ((X) == '_') || \
                             ((X) == ',') || ((X) == '.') || ((X) == '!') || ((X) == '*') || \
                             ((X) == ':'))

#ifndef HAVE_STRL
/* Avoid possible naming collisions during link since
 * we prefer to use the actual name. */
#define strlcpy(dst, src, size) strlcpy_retro__(dst, src, size)
#define strlcat(dst, src, size) strlcat_retro__(dst, src, size)
size_t strlcpy(char *dest, const char *source, size_t size);
size_t strlcat(char *dest, const char *source, size_t size);
#endif

#define __unused(x) [&x]{}()

// Ends C function definitions when using C++.
#ifdef __cplusplus
}
#endif

#include "close_code.h"

#endif //MIMIC_STDINC_H
