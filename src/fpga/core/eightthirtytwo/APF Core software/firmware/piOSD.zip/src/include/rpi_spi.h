/*******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2005-2021, The Raetro authors and contributors
 *******************************************************************************
 *
 * PiSPi
 * Copyright (c) 2005-2021, The Raetro Authors (see AUTHORS file)
 *
 * PiSPi is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the
 * Free Software Foundation, version 3 or (at your option) any later version.
 *
 * PiSPi is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with PiSPi. If not, see <https://www.gnu.org/licenses>.
 *
 ******************************************************************************/

/*!*****************************************************************************
 * @file rpi_spi.h
 * @brief 
 ******************************************************************************/

#ifndef PISPI_RPI_SPI_H
#define PISPI_RPI_SPI_H

#include "stdinc.h"
#include "begin_code.h"
// Set up for C function definitions, even when using C++.
#ifdef __cplusplus
extern "C" {
#endif

/* chip select */
void spi_enable_osd();
void spi_disable_osd();

/* generic helper */
Uint8 spi_in();
void spi8(Uint8 parm);
void spi16(Uint16 parm);
void spi16le(Uint16 parm);
void spi24(Uint32 parm);
void spi32(Uint32 parm);
void spi32le(Uint32 parm);
void spi_n(Uint8 value, Uint16 cnt);

/* OSD related SPI functions */
void spi_osd_cmd_cont(Uint8 cmd);
void spi_osd_cmd(Uint8 cmd);
void spi_osd_cmd8_cont(Uint8 cmd, Uint8 parm);
void spi_osd_cmd8(Uint8 cmd, Uint8 parm);
void spi_osd_cmd32_cont(Uint8 cmd, Uint32 parm);
void spi_osd_cmd32(Uint8 cmd, Uint32 parm);
void spi_osd_cmd32le_cont(Uint8 cmd, Uint32 parm);
void spi_osd_cmd32le(Uint8 cmd, Uint32 parm);

#ifdef __cplusplus
}
#endif

#include "close_code.h"

#endif //PISPI_RPI_SPI_H
