/*******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2005-2021, The Raetro authors and contributors
 *******************************************************************************
 *
 * PiSPi
 * Copyright (c) 2005-2021, The Raetro Authors (see AUTHORS file)
 *
 * PiSPi is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the
 * Free Software Foundation, version 3 or (at your option) any later version.
 *
 * PiSPi is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with PiSPi. If not, see <https://www.gnu.org/licenses>.
 *
 ******************************************************************************/

/*!*****************************************************************************
 * @file rpi_spi.cpp
 * @brief
 ******************************************************************************/

#include "mimic.h"

static inline Uint8 SPI(Uint8 outByte) {
	DISK_LED_ON;
	Uint8 data = rpi_io_spi_transfer(outByte);
	DISK_LED_OFF;
	return data;
}

////////////////////////////////////////////////////////////////////

void spi_enable_osd() {
	LOG_SPI("SPI CS0 => OSD: ENABLE");
	rpi_io_spi_set_cs_polarity(RPI_SPI_CS0, HIGH);
}

void spi_disable_osd() {
	LOG_SPI("SPI CS0 => OSD: DISABLE");
	rpi_io_spi_set_cs_polarity(RPI_SPI_CS0, LOW);
}

////////////////////////////////////////////////////////////////////

Uint8 spi_in() {
	return SPI(0);
}

void spi8(Uint8 parm) {
	SPI(parm);
}

void spi16(Uint16 parm) {
	SPI(parm >> 8);
	SPI(parm >> 0);
}

void spi24(Uint32 parm) {
	SPI(parm >> 16);
	SPI(parm >> 8);
	SPI(parm >> 0);
}

void spi32(Uint32 parm) {
	SPI(parm >> 24);
	SPI(parm >> 16);
	SPI(parm >> 8);
	SPI(parm >> 0);
}

void spi32le(Uint32 parm) {
	SPI(parm >> 0);
	SPI(parm >> 8);
	SPI(parm >> 16);
	SPI(parm >> 24);
}

void spi_n(Uint8 value, Uint16 cnt) {
	while(cnt--) {
		SPI(value);
	}
}

/* OSD related SPI functions */
void spi_osd_cmd_cont(Uint8 cmd) {
	spi_enable_osd();
	SPI(cmd);
}

void spi_osd_cmd(Uint8 cmd) {
	spi_osd_cmd_cont(cmd);
	spi_disable_osd();
}

void spi_osd_cmd8_cont(Uint8 cmd, Uint8 parm) {
	spi_enable_osd();
	SPI(cmd);
	SPI(parm);
}

void spi_osd_cmd8(Uint8 cmd, Uint8 parm) {
	spi_osd_cmd8_cont(cmd, parm);
	spi_disable_osd();
}

void spi_osd_cmd32_cont(Uint8 cmd, Uint32 parm) {
	spi_enable_osd();
	SPI(cmd);
	spi32(parm);
}

void spi_osd_cmd32(Uint8 cmd, Uint32 parm) {
	spi_osd_cmd32_cont(cmd, parm);
	spi_disable_osd();
}

void spi_osd_cmd32le_cont(Uint8 cmd, Uint32 parm) {
	spi_enable_osd();
	SPI(cmd);
	spi32le(parm);
}

void spi_osd_cmd32le(Uint8 cmd, Uint32 parm) {
	spi_osd_cmd32le_cont(cmd, parm);
	spi_disable_osd();
}
