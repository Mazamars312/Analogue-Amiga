/*******************************************************************************
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2005-2021, The Raetro authors and contributors
 *******************************************************************************
 *
 * PiSPi
 * Copyright (c) 2005-2021, The Raetro Authors (see AUTHORS file)
 *
 * PiSPi is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the
 * Free Software Foundation, version 3 or (at your option) any later version.
 *
 * PiSPi is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with PiSPi. If not, see <https://www.gnu.org/licenses>.
 *
 ******************************************************************************/

/*!*****************************************************************************
 * @file close_code.h
 * @brief Header to reverse the effects of begin_code.h.
 *
 * This file reverses the effects of begin_code.h and should be included
 * after you finish any function and structure declarations in your headers
 ******************************************************************************/

#ifndef BEGIN_CODE_H
#error close_code.h included without matching begin_code.h
#endif
#undef BEGIN_CODE_H
