extern void timer_init();
extern uint8_t centis;

