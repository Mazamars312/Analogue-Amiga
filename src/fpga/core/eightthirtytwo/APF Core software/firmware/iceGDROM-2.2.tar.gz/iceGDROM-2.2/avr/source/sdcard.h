extern bool sd_init();
extern bool sd_read_block(uint32_t blk, uint8_t *ptr);
