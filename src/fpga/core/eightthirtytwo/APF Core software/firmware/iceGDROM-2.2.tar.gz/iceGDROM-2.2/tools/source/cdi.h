#include <stdio.h>

extern bool cdi_check_file(FILE *);
extern bool cdi_parse_and_add_tracks(FILE *, const char *);


