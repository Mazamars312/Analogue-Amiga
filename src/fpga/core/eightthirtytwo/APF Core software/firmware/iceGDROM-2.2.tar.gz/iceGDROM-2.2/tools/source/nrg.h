#include <stdio.h>

extern bool nrg_check_file(FILE *);
extern bool nrg_parse_and_add_tracks(FILE *, const char *);
