extern void delay1ms();
extern void delayms(uint8_t ms);
extern void delaycycles(uint8_t cycles);

