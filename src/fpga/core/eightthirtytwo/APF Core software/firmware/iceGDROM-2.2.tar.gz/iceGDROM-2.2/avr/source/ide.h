extern void service_ide();
extern void set_disk_type(uint8_t type);
extern void set_secnr();

