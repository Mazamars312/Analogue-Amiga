extern void aica_init(void);
extern void aica_pause(void);
extern void aica_play_stereo_sample(const short *stereo_buffer, int sample_cnt);
extern int aica_check_sample_playback();
