#include <stdio.h>

extern bool cdrdao_check_file(FILE *);
extern bool cdrdao_parse_and_add_tracks(FILE *, const char *);
